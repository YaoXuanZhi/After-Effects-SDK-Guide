#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl42/types.h>
#include <glbinding/gl42ext/types.h>
#include <glbinding/gl42/boolean.h>
#include <glbinding/gl42ext/boolean.h>
#include <glbinding/gl42/values.h>
#include <glbinding/gl42ext/values.h>
#include <glbinding/gl42/bitfield.h>
#include <glbinding/gl42ext/bitfield.h>
#include <glbinding/gl42/enum.h>
#include <glbinding/gl42ext/enum.h>
#include <glbinding/gl42/functions.h>
#include <glbinding/gl42ext/functions.h>
