
/* This file should be included after all headers, but before the definition of any suites
or data structures.
*/
#include <adobesdk/config/PreConfig.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _AE_GENERAL_PLUG_PRE___
#error "AE_GeneralPlugPre.h not balanced"
#endif

#define _AE_GENERAL_PLUG_PRE___