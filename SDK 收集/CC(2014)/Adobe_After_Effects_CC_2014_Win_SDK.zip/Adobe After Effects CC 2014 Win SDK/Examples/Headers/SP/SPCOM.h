/*  (c) Copyright 2002.  Adobe Systems, Incorporated.  All rights reserved. */
/* $Id: $  */
/* $DateTime: $  */
/* $Change: $  */
/* $Author: $  */

#pragma once

#ifndef __SPCOM__
#define __SPCOM__
/* This module is obsolete. */
#endif // __SPCOM__

