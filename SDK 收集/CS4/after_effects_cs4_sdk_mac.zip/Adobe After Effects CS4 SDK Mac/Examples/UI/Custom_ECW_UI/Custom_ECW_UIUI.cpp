/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

#include "Custom_ECW_UI.h"

static PF_Err
DrawEvent(	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extra)
{
	PF_Err			err		=	PF_Err_NONE;
	A_long			widthL 	= 	0, 
		heightL = 	0;
	
#ifdef AE_OS_WIN
	void*			dp = (*(event_extra->contextH))->cgrafptr;
	HGDIOBJ			oldfont	=	NULL;
	HDC				ecw_hdc	=	NULL;
	COLORREF		color 	=	RGB(params[ECW_UI_COLOR]->u.cd.value.red,
									params[ECW_UI_COLOR]->u.cd.value.green,
									params[ECW_UI_COLOR]->u.cd.value.blue);
	HBRUSH			brush	=	CreateSolidBrush(color);
	RECT			onscreen_rect;
		
	PF_GET_CGRAF_DATA(dp, PF_CGrafData_HDC, (void**)&ecw_hdc);
#else
	RGBColor		color;
	Rect			onscreen_rect, cur_frame = *(Rect*)&event_extra->effect_win.current_frame;
	color.red		=	(unsigned short) (params[ECW_UI_COLOR]->u.cd.value.red		<< 8); 
	color.green		=	(unsigned short) (params[ECW_UI_COLOR]->u.cd.value.green	<< 8);
	color.blue		=	(unsigned short) (params[ECW_UI_COLOR]->u.cd.value.blue		<< 8);	
#endif
	event_extra->evt_out_flags = 0;

	if (	!(event_extra->evt_in_flags & PF_EI_DONT_DRAW) && 
			PF_EA_CONTROL == event_extra->effect_win.area){
		onscreen_rect.left		= event_extra->effect_win.current_frame.left;
		onscreen_rect.top		= event_extra->effect_win.current_frame.top;
		onscreen_rect.right		= event_extra->effect_win.current_frame.right;
		onscreen_rect.bottom	= event_extra->effect_win.current_frame.bottom;
		
		widthL	= onscreen_rect.right	- onscreen_rect.left;
		heightL	= onscreen_rect.bottom	- onscreen_rect.top;

#ifdef AE_OS_WIN
		brush = CreateSolidBrush(color);
		FillRect(ecw_hdc, &onscreen_rect, brush);
		oldfont = SelectObject(ecw_hdc, GetStockObject(ANSI_VAR_FONT));
		SetTextColor(ecw_hdc, RGB(255, 255, 255));
		SetBkColor(ecw_hdc, color);
		TextOut(ecw_hdc, (int)(event_extra->effect_win.current_frame.left + 70), (int)(event_extra->effect_win.current_frame.top + 40), "Whoopee! A Custom UI!!!", 23);	
		brush = (HBRUSH)SelectObject(ecw_hdc, oldfont);
		DeleteObject(brush);
#else
		RGBBackColor(&color);
		EraseRect(&event_extra->effect_win.current_frame);
#endif	
	} 
	if (!err){
		event_extra->evt_out_flags = PF_EO_HANDLED_EVENT;	
	}
	return err;
}

static PF_Err 
DoDrag(	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extra)
{
	PF_Err 			err			= PF_Err_NONE;
	PF_ContextH		contextH	= event_extra->contextH;
	PF_Point		mouse_down;
	
	if (PF_Window_EFFECT == (*contextH)->w_type){
		if (PF_EA_CONTROL == event_extra->effect_win.area) {
			mouse_down = event_extra->u.do_click.screen_point;
			event_extra->u.do_click.continue_refcon[1] = mouse_down.h;
			params[ECW_UI_COLOR]->u.cd.value.red	= (unsigned char)((mouse_down.h << 8) / UI_BOX_WIDTH);
			params[ECW_UI_COLOR]->u.cd.value.blue	= (unsigned char)((mouse_down.v << 8) / UI_BOX_HEIGHT);
			params[ECW_UI_COLOR]->u.cd.value.green	= (unsigned char)(params[ECW_UI_COLOR]->u.cd.value.red + params[ECW_UI_COLOR]->u.cd.value.blue);
			params[ECW_UI_COLOR]->u.cd.value.alpha	= (unsigned char)0xFF;
			params[ECW_UI_COLOR]->uu.change_flags	= PF_ChangeFlag_CHANGED_VALUE;
		}
	}
	
	ERR(DrawEvent(	in_data, 
					out_data, 
					params, 
					output, 
					event_extra)); 
	return err;
}

static PF_Err 
DoClick(
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extra)
{
	PF_Err	err		=	PF_Err_NONE;

	AEGP_SuiteHandler		suites(in_data->pica_basicP);
	PF_ExtendedSuiteTool	tool = PF_ExtendedSuiteTool_MAGNIFY;
	
	ERR(suites.HelperSuite2()->PF_SetCurrentExtendedTool(tool));
	ERR(DoDrag(	in_data, 
				out_data, 
				params, 
				output, 
				event_extra));
	if (!err){
		event_extra->u.do_click.send_drag 	= TRUE;
		event_extra->evt_out_flags 			= PF_EO_HANDLED_EVENT;
	}
	return err;
}

static PF_Err 
ChangeCursor(	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extra)
{
	if (PF_Mod_SHIFT_KEY & event_extra->u.adjust_cursor.modifiers)	{
		event_extra->u.adjust_cursor.set_cursor = PF_Cursor_EYEDROPPER;
	} else {
		if (PF_Mod_CMD_CTRL_KEY & event_extra->u.adjust_cursor.modifiers) {
			event_extra->u.adjust_cursor.set_cursor = PF_Cursor_HOLLOW_ARROW;
		}
	}
	return PF_Err_NONE;
}

PF_Err 
HandleEvent(	
				PF_InData		*in_data,
				PF_OutData		*out_data,
				PF_ParamDef		*params[],
				PF_LayerDef		*output,
				PF_EventExtra	*extra)
{
	PF_Err		err		= PF_Err_NONE;
	
	switch (extra->e_type) {
		case PF_Event_DO_CLICK:
			err =	DoClick(in_data, 
							out_data, 
							params, 
							output, 
							extra);
			break;
			
		case PF_Event_DRAG:
			err =	DoDrag(	in_data, 
							out_data, 
							params, 
							output, 
							extra);
			break;
			
		case PF_Event_DRAW:
			err =	DrawEvent(	in_data, 
								out_data, 
								params, 
								output, 
								extra);
			break;
			
		case PF_Event_ADJUST_CURSOR:
			err	=	ChangeCursor(	in_data, 
									out_data, 
									params, 
									output, 
									extra);
			
			break;
		default:
			break;
	}
	return err;
}

