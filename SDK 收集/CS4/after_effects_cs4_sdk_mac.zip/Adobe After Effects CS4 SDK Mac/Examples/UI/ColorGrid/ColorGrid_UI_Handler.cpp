/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

#include "ColorGrid.h"

PF_Boolean
ColorGrid_PointInRect(
	PF_Point			point,			/*>>*/ 
	PF_Rect				rect)			/*>>*/
{
	PF_Boolean		result = FALSE;

	if(	point.h > rect.left		&&
		point.h < rect.right	&&
		point.v > rect.top		&&
		point.v < rect.bottom){	result = TRUE; }

	return result;
}

PF_Err
ColorGrid_Get_Box_In_Grid(
	const PF_Point		*origin,		/*>>*/
	A_long				grid_width,		/*>>*/
	A_long				grid_height,	/*>>*/
	A_long				box_across,		/*>>*/
	A_long				box_down,		/*>>*/
	PF_Rect				*box_in_rect)	/*<<*/
{
	PF_Err			err			= PF_Err_NONE;
	A_short			box_width	= 0,
					box_height	= 0;

	// Given the grid h+w and the box coord (0,0 through BOXES_ACROSS,BOXES_DOWN)
	// return the rect of the box

	box_width	= (A_short)(grid_width 	/ BOXES_ACROSS);
	box_height	= (A_short)(grid_height	/ BOXES_DOWN);

	box_in_rect->left	= (A_short)(box_width 	* box_across) 	+ origin->h;
	box_in_rect->top	= (A_short)(box_height 	* box_down) 	+ origin->v;
	box_in_rect->right	= (A_short)box_in_rect->left 			+ box_width;
	box_in_rect->bottom	= (A_short)box_in_rect->top 			+ box_height;

	return err;

}

PF_Err
ColorGrid_GetNewColor(
	PF_InData		*in_data,
	A_long			hposL,
	A_long			vposL,
	CG_ArbData		*arbP)
{
	PF_Err				err					= PF_Err_NONE;
	PF_PixelFloat	*box_colorP		= NULL;
	A_long			posL = vposL * (BOXES_ACROSS) + hposL;

	box_colorP	= arbP->colorA;
	box_colorP	+= posL;

	AEGP_SuiteHandler suites(in_data->pica_basicP);

	// Premiere Pro/Elements don't support PF_AppColorPickerDialog
	if (in_data->appl_id != 'PrMr') {
		ERR(suites.AppSuite3()->PF_AppColorPickerDialog("ColorGrid!",
														box_colorP,
														TRUE,
														box_colorP));
	} else 	{
		box_colorP->red = (PF_FpShort)(rand() % PF_MAX_CHAN8) / 255.0;
		box_colorP->green = (PF_FpShort)(rand() % PF_MAX_CHAN8) / 255.0;
		box_colorP->blue = (PF_FpShort)(rand() % PF_MAX_CHAN8) / 255.0;
	}

	return err;
}

PF_Err
DoClick(
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*extra)
{
	PF_Err				err					= PF_Err_NONE;
	CG_ArbData			*arbP				= NULL;
	PF_Handle			arbH				= params[CG_GRID_UI]->u.arb_d.value;
	PF_Rect				box_rect;
	PF_Rect				grid_rect;

	PF_Point			mouse_pt, origin;
	A_char				count				= 0;
	A_long				box_across			= 0,
						box_down			= 0;
	PF_Boolean			point_in_rectB		= FALSE;
	
	AEGP_SuiteHandler		suites(in_data->pica_basicP);

	// Get the AdvAppSuite1 PICA suite to do Info window text in the 4.x and later style
	arbP	= reinterpret_cast<CG_ArbData*>(PF_LOCK_HANDLE(arbH));

	/*
		Do the hit detection of where in the UI the user clicked, 
		determine which of the custom UI grids needs updating, 
		update and refresh UI appropriately
	*/
	
	if(!err){
		mouse_pt.v	= extra->u.do_click.screen_point.v;
		mouse_pt.h	= extra->u.do_click.screen_point.h;
		origin.h	= extra->effect_win.current_frame.left;
		origin.v	= extra->effect_win.current_frame.top;

		grid_rect.top	= origin.v;
		grid_rect.left	= origin.h;
		grid_rect.right = grid_rect.left + UI_GRID_WIDTH;
		grid_rect.bottom = grid_rect.top + UI_GRID_HEIGHT;

		if (extra->effect_win.area == PF_EA_CONTROL){	
			// Is the click in the grid?
			if(ColorGrid_PointInRect(mouse_pt,grid_rect)){
				for(count = 0; count < CG_ARBDATA_ELEMENTS; count++)
				{
					ColorGrid_Get_Box_In_Grid(	&origin,
												UI_GRID_WIDTH,
												UI_GRID_HEIGHT,
												box_across,
												box_down,
												&box_rect);

					point_in_rectB = ColorGrid_PointInRect(mouse_pt,box_rect);
					
					if(point_in_rectB){
						count = CG_ARBDATA_ELEMENTS;
					} else {
						++box_across;
						if(box_across == BOXES_ACROSS){
							++box_down;
							box_across = 0;
						}
					}
				}

				err = ColorGrid_GetNewColor(in_data, 
											box_across,
											box_down,
											arbP);
				
				extra->evt_out_flags					|= PF_EO_HANDLED_EVENT;
				params[CG_GRID_UI]->uu.change_flags 	|= PF_ChangeFlag_CHANGED_VALUE;
				out_data->out_flags						|= PF_OutFlag_REFRESH_UI;
			}
			PF_UNLOCK_HANDLE(arbH);
		}
	}

	// Premiere Pro/Elements does not support this suite
	if (in_data->appl_id != 'PrMr')
	{
		ERR(suites.AdvAppSuite2()->PF_InfoDrawText("ColorGrid - DoClick Event","Adobe Systems, Inc"));
	}

	return err;
}

PF_Err
Deactivate(
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*extra)
{
	PF_Err 				err 	= PF_Err_NONE;

	AEGP_SuiteHandler		suites(in_data->pica_basicP);

	// Premiere Pro/Elements does not support this suite
	if (in_data->appl_id != 'PrMr')
	{
		ERR(suites.AdvAppSuite2()->PF_InfoDrawText("ColorGrid - Deactivate Event","Adobe Systems, Inc"));
	}

	return err;
}


PF_Err 
DrawEvent(	
		PF_InData			*in_data,
		PF_OutData			*out_data,
		PF_ParamDef			*params[],
		PF_LayerDef			*output,
		PF_EventExtra		*event_extra,
		PF_Pixel			some_color)
{
	PF_Err				err				= PF_Err_NONE;

	// Setup the arb data handling
	PF_Handle			arbH			= params[CG_GRID_UI]->u.arb_d.value;
	CG_ArbData			*arbP;
	PF_Point			origin;
	A_long				box_across		= 0,
						box_down		= 0;
	PF_Rect				box_rect;
	A_u_char			i				= 0;
	PF_PixelFloat		*pixP			= NULL;	
#ifdef AE_OS_WIN
	void*				dp = (*(event_extra->contextH))->cgrafptr;
	HDC					ecw_hdc	=	NULL;
	HBRUSH				Brush;
	COLORREF			bg_color;
	RECT				onscreen_rect;
	RECT				win_box_rect;

	COLORREF			pixel_colr[CG_ARBDATA_ELEMENTS];
	PF_App_Color		app_color;

	PF_GET_CGRAF_DATA((PF_ProgPtr)dp, PF_CGrafData_HDC, (void**)&ecw_hdc);

	ERR(AcquireBackgroundColor(	in_data,
								out_data,
								params,
								event_extra,
								&app_color));
	
	bg_color = RGB(app_color.red,app_color.green,app_color.blue);

#else	// MacOS
	Rect			onscreen_rect, cur_frame = *(Rect*)&event_extra->effect_win.current_frame;
	RGBColor		bg_color;
	RGBColor		pixel_colr[CG_ARBDATA_ELEMENTS];

	ERR(AcquireBackgroundColor(	in_data,
								out_data,
								params,
								event_extra,
								reinterpret_cast<PF_App_Color*>(&bg_color)));
#endif
	
	if (!err && event_extra->effect_win.area == PF_EA_CONTROL) {
		// Use to fill background with AE's BG color
		onscreen_rect.left 		= event_extra->effect_win.current_frame.left;
		onscreen_rect.top		= event_extra->effect_win.current_frame.top;
		onscreen_rect.right 	= event_extra->effect_win.current_frame.right;
		onscreen_rect.bottom 	= event_extra->effect_win.current_frame.bottom + 1;

		origin.v	= (short)onscreen_rect.top;
		origin.h	= (short)onscreen_rect.left;
	}

#ifdef AE_OS_WIN
	// Fill the background rect with BG color
	Brush = CreateSolidBrush(bg_color);
	FillRect(ecw_hdc, &onscreen_rect, Brush);
	DeleteObject(Brush);
#else	// MacOS
	
	// Fill the background rect with BG color
	RGBBackColor(&bg_color);
	EraseRect(&event_extra->effect_win.current_frame);
#endif	

	// Get the arb data to fill out the grid colors
	arbP = (CG_ArbData*)PF_LOCK_HANDLE(arbH);

	if(arbP) {
		pixP = reinterpret_cast<PF_PixelFloat*>(arbP);	

#ifdef AE_OS_WIN
		for(i = 0; i < CG_ARBDATA_ELEMENTS; i++) {

			pixel_colr[i] = RGB((A_u_short)(pixP->red * PF_MAX_CHAN8),
								(A_u_short)(pixP->green * PF_MAX_CHAN8),
								(A_u_short)(pixP->blue * PF_MAX_CHAN8));
			pixP++;
		}

		for(i=0;i<BOXES_PER_GRID;i++){
			// Fill in our grid
			Brush = CreateSolidBrush(pixel_colr[i]);
			ERR(ColorGrid_Get_Box_In_Grid(	&origin,
											UI_GRID_WIDTH,
											UI_GRID_HEIGHT,
											box_across,
											box_down,
											&box_rect));

			PF_Rect_To_Win_Rect(&box_rect,&win_box_rect);
			FillRect(ecw_hdc, &win_box_rect,Brush);
			DeleteObject(Brush);
			box_across++;
			if(box_across == BOXES_ACROSS)	{
				box_across = 0;
				box_down++;
			}
		}	
#else // MacOS
		for(i = 0; i < CG_ARBDATA_ELEMENTS; ++i) {

			PF_FpShort scaling_factorF = (2 * PF_MAX_CHAN16) - 1;
			
			pixel_colr[i].red 	= (A_u_short)(pixP->red * scaling_factorF);
			pixel_colr[i].green = (A_u_short)(pixP->green * scaling_factorF);
			pixel_colr[i].blue 	= (A_u_short)(pixP->blue * scaling_factorF);
			pixP++;
		}
		
		for(i=0;i<BOXES_PER_GRID;i++) {
			// Fill in our grid
			bg_color = pixel_colr[i];
			RGBForeColor(&bg_color);
			
			ERR(ColorGrid_Get_Box_In_Grid(	&origin,
											UI_GRID_WIDTH,
											UI_GRID_HEIGHT,
											box_across,
											box_down,
											&box_rect));
			
			PaintRect(&box_rect);
			box_across++;
			if(box_across == BOXES_ACROSS){
				box_across = 0;
				box_down++;
			}
		}
#endif
	}

	// Draw the grid - outline
	for(box_down = 0; box_down < BOXES_DOWN; ++box_down){
		for(box_across = 0; box_across < BOXES_ACROSS; ++box_across) {
			ERR(ColorGrid_Get_Box_In_Grid(	&origin,
											UI_GRID_WIDTH,
											UI_GRID_HEIGHT,
											box_across,
											box_down,
											&box_rect));
#ifdef AE_OS_WIN
			PF_Rect_To_Win_Rect(&box_rect,&win_box_rect);	
			FrameRect(ecw_hdc,&win_box_rect,(HBRUSH)GetStockObject(BLACK_BRUSH));
#else // MacOS
			bg_color.red = bg_color.green = bg_color.blue = 0;
			RGBForeColor(&bg_color);
			FrameRect(&box_rect);
#endif
		}
	}
	PF_UNLOCK_HANDLE(arbH);
	event_extra->evt_out_flags = PF_EO_HANDLED_EVENT;	
	return err;
}

PF_Err 
ChangeCursor(	
		PF_InData			*in_data,
		PF_OutData			*out_data,
		PF_ParamDef			*params[],
		PF_LayerDef			*output,
		PF_EventExtra		*extra)
{
	PF_Err				err					= PF_Err_NONE;

	PF_Point			origin;	
	PF_Point			mouse_pt;
	PF_Rect				grid_rect;

	AEGP_SuiteHandler		suites(in_data->pica_basicP);

	//	Determine where the mouse is, and sent the info window the appropriate color
	//	and change the cursor only when over the ColorGrid
	if(!err) {
		mouse_pt.v	= extra->u.adjust_cursor.screen_point.v;
		mouse_pt.h	= extra->u.adjust_cursor.screen_point.h;
		origin.h	= extra->effect_win.current_frame.left;
		origin.v	= extra->effect_win.current_frame.top;

		grid_rect.top		= origin.v;
		grid_rect.left		= origin.h;
		grid_rect.right 	= grid_rect.left 	+ UI_GRID_WIDTH;
		grid_rect.bottom 	= grid_rect.top 	+ UI_GRID_HEIGHT;

		if (extra->effect_win.area == PF_EA_CONTROL){	
			// Is the click in the grid?
			if(ColorGrid_PointInRect(mouse_pt,grid_rect)){
				extra->u.adjust_cursor.set_cursor = PF_Cursor_EYEDROPPER;
			}
		}
	}

	// Premiere Pro/Elements does not support this suite
	if (in_data->appl_id != 'PrMr')
	{
		ERR(suites.AdvAppSuite2()->PF_InfoDrawText("ColorGrid - ChangeCursor Event","Adobe Systems, Inc"));
	}

	return err;
}


