
/* This file should be included after all headers, but before the definition of any suites
or data structures.
*/
#if PRAGMA_STRUCT_ALIGN
#pragma options align=power
#endif

#ifdef _WINDOWS
#pragma pack( push, AEalign4, 4 )
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _AE_GENERAL_PLUG_PRE___
#error "AE_GeneralPlugPre.h not balanced"
#endif

#define _AE_GENERAL_PLUG_PRE___