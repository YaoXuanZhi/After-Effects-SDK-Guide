
#ifdef __cplusplus
}		// end extern "C"
#endif


#if PRAGMA_STRUCT_ALIGN
#pragma options align=reset
#endif

#ifdef _WINDOWS
#pragma pack( pop, AEalign4)
#endif



#ifndef _AE_GENERAL_PLUG_PRE___
	#error "AE_GeneralPlugPost.h not balanced"
#else
	#undef _AE_GENERAL_PLUG_PRE___
#endif