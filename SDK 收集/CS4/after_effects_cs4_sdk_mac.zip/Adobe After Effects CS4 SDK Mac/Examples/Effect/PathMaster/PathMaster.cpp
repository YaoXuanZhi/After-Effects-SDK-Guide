/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/


/*	PathMaster.cpp

	This sample shows how to access and rasterize paths using 
	PICA suites.

	Revision history: 

	1.0 First release								bbb		6/28/00		

	2.0 Updated to "old school" coding guidelines,	bbb		5/20/03
		added mask color fiddling		
		
	3.0 Added sequence data handling				bbb		8/1/06
		
*/

#include "PathMaster.h"

static PF_Err 
About (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PF_Err err = PF_Err_NONE;
	AEGP_SuiteHandler suites(in_data->pica_basicP);

	suites.ANSICallbacksSuite1()->sprintf(out_data->return_msg,
								"%s v%d.%d\r%s",
								STR(StrID_Name), 
								MAJOR_VERSION, 
								MINOR_VERSION, 
								STR(StrID_Description));
	return err;
}

static PF_Err 
GlobalSetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{	
	PF_Err err = PF_Err_NONE;
	
	if (in_data->version.major >= 12 && in_data->version.minor >= 5){	/* 5.0 == API version 12.5 */
		out_data->my_version = PF_VERSION(	MAJOR_VERSION, 
											MINOR_VERSION,
											BUG_VERSION, 
											STAGE_VERSION, 
											BUILD_VERSION);
		
		out_data->out_flags |= 	PF_OutFlag_I_EXPAND_BUFFER					|
								PF_OutFlag_KEEP_RESOURCE_OPEN				|
								PF_OutFlag_I_HAVE_EXTERNAL_DEPENDENCIES		|
								PF_OutFlag_SEQUENCE_DATA_NEEDS_FLATTENING	|
								PF_OutFlag_DEEP_COLOR_AWARE;
	} else {
		PF_STRCPY(out_data->return_msg, STR(StrID_API_Vers_Warning));			
		out_data->out_flags	=	PF_OutFlag_DISPLAY_ERROR_MESSAGE;
		err					=	PF_Err_INTERNAL_STRUCT_DAMAGED;
	}
	return err;
}

static PF_Err 
SequenceSetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{
	PF_Err err = PF_Err_NONE;
	AEGP_SuiteHandler suites(in_data->pica_basicP);
	PF_Handle	seq_dataH =	suites.HandleSuite1()->host_new_handle(sizeof(Unflat_Seq_Data));

	if (seq_dataH){
		Unflat_Seq_Data	*seqP = static_cast<Unflat_Seq_Data*>(suites.HandleSuite1()->host_lock_handle(seq_dataH));

		if (seqP){
			
			// We need to allocate some non-flat memory for this arbitrary string.
			// Notice that we're using AE's memory allocation callbacks to do so.
			// Do this.
			
			PF_Handle unflat_charsH	=	suites.HandleSuite1()->host_new_handle(PF_MAX_EFFECT_MSG_LEN);

			if (unflat_charsH){
				// ...and we need to lock it before we use it.
				seqP->blahZ = static_cast<A_char*>(suites.HandleSuite1()->host_lock_handle(unflat_charsH));
			}

			//	WARNING: The following assignments are not safe for cross-platform use.
			//	Production code would enforce byte order consistency, across platforms.
			
			suites.ANSICallbacksSuite1()->strcpy(seqP->blahZ, STR(StrID_Really_Long_String));
			seqP->fixed_valF		= 123;
			seqP->flatB				= FALSE;
			out_data->sequence_data = seq_dataH;
		}
	} else {	// whoa, we couldn't allocate sequence data; bail!
		err = PF_Err_OUT_OF_MEMORY;
	}
	return err;
}

static PF_Err 
SequenceSetdown (	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{
	PF_Err err = PF_Err_NONE;
	
	// Flat or unflat, get rid of it.
	
	if (in_data->sequence_data){
		AEGP_SuiteHandler suites(in_data->pica_basicP);
		suites.HandleSuite1()->host_dispose_handle(in_data->sequence_data);
	}
	return err;
}

static PF_Err 
SequenceFlatten(	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{
	PF_Err err = PF_Err_NONE;
	AEGP_SuiteHandler suites(in_data->pica_basicP);

	// Make a flat copy of whatever is in the unflat seq data handed to us. 
	// Do NOT delete the unflat one!
	
	if (in_data->sequence_data){
		Unflat_Seq_Data*	unflat_seq_dataP = static_cast<Unflat_Seq_Data*>(suites.HandleSuite1()->host_lock_handle(in_data->sequence_data));

		if (unflat_seq_dataP){
			PF_Handle flat_seq_dataH = suites.HandleSuite1()->host_new_handle(sizeof(Flat_Seq_Data));

			if (flat_seq_dataH){
				Flat_Seq_Data*	flat_seq_dataP = static_cast<Flat_Seq_Data*>(suites.HandleSuite1()->host_lock_handle(flat_seq_dataH));

				if (flat_seq_dataP){
					flat_seq_dataP->flatB		= TRUE;
					flat_seq_dataP->fixed_valF	= unflat_seq_dataP->fixed_valF;
					#ifdef AE_OS_WIN
						strncpy_s(flat_seq_dataP->blah, unflat_seq_dataP->blahZ,PF_MAX_EFFECT_MSG_LEN);
					#else
						strncpy(flat_seq_dataP->blah, unflat_seq_dataP->blahZ,PF_MAX_EFFECT_MSG_LEN);
					#endif	
					out_data->sequence_data = flat_seq_dataH;
					suites.HandleSuite1()->host_unlock_handle(flat_seq_dataH);
				}
			} else {
				err = PF_Err_INTERNAL_STRUCT_DAMAGED;
			}
		}
	} else {
		err = PF_Err_INTERNAL_STRUCT_DAMAGED;
	}
	return err;
}

static PF_Err 
SequenceResetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{
	PF_Err err = PF_Err_NONE;
	AEGP_SuiteHandler suites(in_data->pica_basicP);

	// We got here because we're either opening a project w/saved (flat) sequence data,
	// or we've just been asked to flatten our sequence data (for a save) and now 
	// we're blowing it back up.
	
	if (in_data->sequence_data){
		Flat_Seq_Data*	flatP = static_cast<Flat_Seq_Data*>(suites.HandleSuite1()->host_lock_handle(in_data->sequence_data));

		if (flatP){
			PF_Handle unflat_seq_dataH = suites.HandleSuite1()->host_new_handle(sizeof(Unflat_Seq_Data));

			if (unflat_seq_dataH){
				Unflat_Seq_Data*	unflatP = static_cast<Unflat_Seq_Data*>(suites.HandleSuite1()->host_lock_handle(unflat_seq_dataH));

				if (unflatP){
					unflatP->fixed_valF = flatP->fixed_valF;	// Warning: NOT X-PLATFORM SAFE!
					unflatP->flatB		= FALSE;
					A_short	lengthS		= strlen(flatP->blah);

					// clamp it to the max flat length
					if (lengthS > PF_MAX_EFFECT_MSG_LEN){
						lengthS = PF_MAX_EFFECT_MSG_LEN;
					} 
					PF_Handle unflat_charsH	=	suites.HandleSuite1()->host_new_handle(lengthS);

					if (unflat_charsH){
						unflatP->blahZ = static_cast<A_char*>(suites.HandleSuite1()->host_lock_handle(unflat_charsH));
						if (unflatP->blahZ){
							suites.ANSICallbacksSuite1()->strcpy(unflatP->blahZ, flatP->blah);

							// if it all went well, set the sequence data to our new, inflated seq data.
							out_data->sequence_data = unflat_seq_dataH;
						}
					} else {
						err = PF_Err_INTERNAL_STRUCT_DAMAGED;
					}
				}
			}
		}
	}
	return err;
}

static PF_Err 
ParamsSetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[])
{
	PF_Err		err		= PF_Err_NONE;
	PF_ParamDef	def;	

	AEFX_CLR_STRUCT(def);
	def.param_type = PF_Param_PATH;
	def.uu.id = PATH_DISK_ID;
	PF_STRCPY(def.name, STR(StrID_PathName)); 
	def.u.path_d.dephault	= 0;

	PF_ADD_PARAM(in_data, -1, &def);

	AEFX_CLR_STRUCT(def);

	PF_ADD_COLOR(	STR(StrID_ColorName), 
					PF_MAX_CHAN8,
					0,
					0,
					COLOR_DISK_ID);
	
	AEFX_CLR_STRUCT(def);
						
  	PF_ADD_FIXED (	STR(StrID_X_Feather),
  					FEATHER_VALID_MIN,
  					FEATHER_VALID_MAX,
  					FEATHER_MIN,
  					FEATHER_MAX,
  					FEATHER_DFLT,
  					1,
  					0,
  					0,
  					X_FEATHER_DISK_ID);
					
	AEFX_CLR_STRUCT(def);

  	PF_ADD_FIXED (	STR(StrID_Y_Feather),
  					FEATHER_VALID_MIN,
  					FEATHER_VALID_MAX,
  					FEATHER_MIN,
  					FEATHER_MAX,
  					FEATHER_DFLT,
  					1,
  					0,
  					0,
  					Y_FEATHER_DISK_ID);

	AEFX_CLR_STRUCT(def);

	PF_ADD_CHECKBOX(	STR(StrID_CheckName), 
						STR(StrID_CheckDetail), 
						FALSE,
						0, 
						DOWNSAMPLE_DISK_ID);
	
	AEFX_CLR_STRUCT(def);

  	PF_ADD_FIXED (	STR(StrID_OpacityName),
  					OPACITY_VALID_MIN,
  					OPACITY_VALID_MAX,
  					OPACITY_VALID_MIN,
  					OPACITY_VALID_MAX,
  					OPACITY_DFLT,
  					OPACITY_PRECISION,
  					PF_ValueDisplayFlag_PERCENT,
  					0,
  					OPACITY_DISK_ID);
	
	out_data->num_params = PATHMASTER_NUM_PARAMS;

	return err;
}


static PF_Err
FillColor(
	A_long		refcon, 
	A_long		xL, 
	A_long		yL, 
	PF_Pixel 	*inP, 
	PF_Pixel 	*outP)
{
	register FillInfo *fiP = reinterpret_cast<FillInfo*>(refcon);
	
	outP->blue	=	static_cast<A_u_char>((inP->blue	+ fiP->color.blue)	/ 2);
	outP->green	=	static_cast<A_u_char>((inP->green	+ fiP->color.green)	/ 2);
	outP->red	=	static_cast<A_u_char>((inP->red		+ fiP->color.red)	/ 2);
	
	if (fiP->invertB) {
		outP->alpha = static_cast<A_u_char>(PF_MAX_CHAN8 - outP->alpha);
	} else {
		outP->alpha	= inP->alpha;
	}
	return PF_Err_NONE;
}

static PF_Err
FillColor16(
	A_long		refcon, 
	A_long		xL, 
	A_long		yL, 
	PF_Pixel16 *inP, 
	PF_Pixel16 *outP)
{
	register FillInfo *fiP = reinterpret_cast<FillInfo*>(refcon);
	
	outP->blue	=	static_cast<A_u_short>((inP->blue	+ fiP->deep_color.blue)		/ 2);
	outP->green	=	static_cast<A_u_short>((inP->green	+ fiP->deep_color.green)	/ 2);
	outP->red	=	static_cast<A_u_short>((inP->red	+ fiP->deep_color.red)		/ 2);
	
	if (fiP->invertB) {
		outP->alpha = static_cast<A_u_short>(PF_MAX_CHAN16 - outP->alpha);
	} else {
		outP->alpha	=	inP->alpha;
	}
	return PF_Err_NONE;
}

static PF_Err 
Render (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output)
{
	PF_Err				err			= PF_Err_NONE,
						err2		= PF_Err_NONE;
						
	PF_EffectWorld		*inputP		= NULL;

	A_long				mask_idL	= 0L;
	PF_PathOutlinePtr	maskP		= 0;
	PF_MaskSuite1		*msP		= NULL;
	PF_Boolean			openB 		= TRUE, 
						renderB 	= FALSE,
						deepB		= PF_WORLD_IS_DEEP(output);
	PF_Pixel			color;
	PF_Pixel16			deep_color;
	AEGP_SuiteHandler	suites(in_data->pica_basicP);


	ERR(AEFX_AcquireSuite(in_data,
						  out_data,
						  kPF_MaskSuite,
						  kPF_MaskSuiteVersion1,
						  STR(StrID_Err_LoadSuite),
						  reinterpret_cast<void**>(&msP)));
						  
	inputP 	= &params[PATHMASTER_INPUT]->u.ld;
	color 	= params[PATHMASTER_COLOR]->u.cd.value;

	// get the path number

	mask_idL	=  params[PATHMASTER_PATH]->u.path_d.path_id;

	if (mask_idL) {
		ERR(suites.PathQuerySuite1()->PF_CheckoutPath(	in_data->effect_ref, 
														mask_idL,
														in_data->current_time,
														in_data->time_step,
														in_data->time_scale,
														&maskP));

		ERR(suites.PathDataSuite1()->PF_PathIsOpen(	in_data->effect_ref, maskP,	&openB));

		if (!err && !openB) {
			PF_FpLong		x_resF 		= in_data->downsample_x.num / 
												static_cast<PF_FpLong>(in_data->downsample_x.den);
			PF_FpLong		y_resF 		= in_data->downsample_y.num / 
												static_cast<PF_FpLong>(in_data->downsample_y.den);
			renderB = TRUE;


			if (deepB){
				deep_color.red		= CONVERT8TO16(color.red);
				deep_color.blue		= CONVERT8TO16(color.blue);
				deep_color.green	= CONVERT8TO16(color.green);
				
				ERR(suites.FillMatteSuite1()->fill16(in_data->effect_ref,
													&deep_color, 
													0, 
													output));
			} else {
				ERR(suites.FillMatteSuite1()->fill(in_data->effect_ref,
												&color, 
												0, 
												output));
			}

			ERR(msP->PF_MaskWorldWithPath(	in_data->effect_ref,
											&maskP,
											FIX_2_FLOAT(params[PATHMASTER_X_FEATHER]->u.fd.value * x_resF), // float version of x feather
											FIX_2_FLOAT(params[PATHMASTER_Y_FEATHER]->u.fd.value * y_resF), // float version of y feather
											params[PATHMASTER_INVERT]->u.bd.value,
											FIX_2_FLOAT(params[PATHMASTER_OPACITY]->u.fd.value), // opacity value
											in_data->quality,
											output,
											&output->extent_hint));
			if (!err) 
			{
				PF_CompositeMode	mode;
				PF_Rect				full;

				full.left 		= 	0;
				full.top		=	0;
				full.bottom 	= 	output->height;
				full.right	 	=  	output->width;

				mode.xfer		= PF_Xfer_IN_FRONT;
				mode.rand_seed	= 0;
				mode.opacity	= PF_MAX_CHAN8;
				mode.rgb_only	= FALSE;
				mode.opacitySu	= PF_MAX_CHAN16;

				err = suites.WorldTransformSuite1()->transfer_rect(	in_data->effect_ref,
																	in_data->quality,
																	PF_MF_Alpha_STRAIGHT,
																	PF_Field_FRAME, 
																	&full,
																	inputP,
																	&mode,
																	NULL,
																	0,
																	0,
																	output);

			}
		} else if (!err) { 
		
			// there is no mask selected
			
			if (in_data->quality == PF_Quality_HI){
				ERR(suites.WorldTransformSuite1()->copy_hq(	in_data->effect_ref,
															inputP,
															output,
															0,
															0));
			} else {
				ERR(suites.WorldTransformSuite1()->copy(in_data->effect_ref,
														inputP,
														output,
														0,
														0));
			}	
			renderB = TRUE;
		}
		ERR2(suites.PathQuerySuite1()->PF_CheckinPath(	in_data->effect_ref, 
														mask_idL,
														FALSE, 
														maskP));
	}

	if (FALSE == renderB) {
		ERR(suites.WorldTransformSuite1()->copy(	in_data->effect_ref,
												inputP,
												output,
												0,
												0));
	}
	if (!err) {		// Fill with color

		FillInfo			fi;
		PF_FpLong			opacityF	= FIX_2_FLOAT(params[PATHMASTER_OPACITY]->u.fd.value);
		fi.opacityCu	= (A_u_char) ((opacityF * PF_MAX_CHAN8) + 0.5);
		fi.opacitySu	= (A_u_short) ((opacityF * PF_MAX_CHAN16) + 0.5);

		if (fi.opacitySu > PF_MAX_CHAN16) {
			fi.opacitySu = PF_MAX_CHAN16;
		}
		
		fi.color		= 
		color 			= params[PATHMASTER_COLOR]->u.cd.value;
		
		fi.invertB		= params[PATHMASTER_INVERT]->u.bd.value;

		if (deepB){
			fi.deep_color.red		= deep_color.red;
			fi.deep_color.blue		= deep_color.blue;
			fi.deep_color.green		= deep_color.green;
			fi.deep_color.alpha		= deep_color.alpha;

			ERR(suites.Iterate16Suite1()->iterate(	in_data,
													0, 
													output->height*2, 
													output,
													0, 
													reinterpret_cast<A_long>(&fi), // Gotta love C-style casts!
													FillColor16, 
													output));
		} else {

			ERR(suites.Iterate8Suite1()->iterate(	in_data,
													0, 
													output->height*2, 
													output,
													0, 
													reinterpret_cast<A_long>(&fi),
													FillColor, 
													output));
		}
	}
	
	//	Here's how to get and set the color of each mask attached to a layer.
	
	AEGP_LayerH 	layerH 		= NULL;
	A_long 			mask_countL = 0;
	AEGP_MaskRefH 	mask_refH 	= NULL;
	AEGP_ColorVal   old_color, new_color;

	ERR(suites.PFInterfaceSuite1()->AEGP_GetEffectLayer(in_data->effect_ref, &layerH));

	ERR(suites.MaskSuite4()->AEGP_GetLayerNumMasks(layerH, &mask_countL));

	for (A_long iL = 0; !err && (iL < mask_countL); ++iL){
	    ERR(suites.MaskSuite4()->AEGP_GetLayerMaskByIndex(layerH, iL, &mask_refH));
	    if (mask_refH){
	        ERR(suites.MaskSuite4()->AEGP_GetMaskColor(mask_refH, &old_color));
	        if (!err){
	        	new_color.redF		= 1 - old_color.greenF;
	        	new_color.greenF	= 1 - old_color.blueF;
	        	new_color.blueF		= 1 - old_color.redF;
	        	ERR(suites.MaskSuite4()->AEGP_SetMaskColor(mask_refH, &new_color));
	        }
	        if (mask_refH){
	        	ERR2(suites.MaskSuite4()->AEGP_DisposeMask(mask_refH));
	        }
	    }
	}
	if(msP){
		ERR2(AEFX_ReleaseSuite(in_data,
							   out_data,
							   kPF_MaskSuite, 
							   kPF_MaskSuiteVersion1,
							   STR(StrID_Err_FreeSuite)));
	}
	return err;
} 

DllExport	PF_Err 
EntryPointFunc (	
					PF_Cmd			cmd,
					PF_InData		*in_data,
					PF_OutData		*out_data,
					PF_ParamDef		*params[],
					PF_LayerDef		*output,
					void			*extra)
{
	PF_Err		err = PF_Err_NONE;
	
	try { 
		switch (cmd) {
			case PF_Cmd_ABOUT:
				err = About(in_data,out_data,params,output);
				break;
			case PF_Cmd_SEQUENCE_SETUP:
				err = SequenceSetup(in_data,out_data);
				break;
			case PF_Cmd_SEQUENCE_SETDOWN:
				err = SequenceSetdown(in_data,out_data);
				break;
			case PF_Cmd_SEQUENCE_FLATTEN:
				err = SequenceFlatten(in_data,out_data);
				break;
			case PF_Cmd_SEQUENCE_RESETUP:
				err = SequenceResetup(in_data,out_data);
				break;
			case PF_Cmd_GLOBAL_SETUP:
				err = GlobalSetup(in_data,out_data);
				break;
			case PF_Cmd_PARAMS_SETUP:
				err = ParamsSetup(in_data,out_data,params);
				break;
			case PF_Cmd_RENDER:
				err = Render(in_data,out_data,params,output);
				break;
			default:
				break;
		}
	} catch(PF_Err &thrown_err) {
		// Never EVER throw exceptions into AE.
		err = thrown_err;
	}
	return err;
}