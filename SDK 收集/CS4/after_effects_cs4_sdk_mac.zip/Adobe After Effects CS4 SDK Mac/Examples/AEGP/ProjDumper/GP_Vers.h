#define VERS			1
#define SUB_VERS		0
#define BUG_VERS		0
#define STAGE			U_Stage_RELEASE
#define BUILD			0
#define NAME			"ProjDumper"
#define INTERNAL_NAME	"ProjDumper.AEX"
