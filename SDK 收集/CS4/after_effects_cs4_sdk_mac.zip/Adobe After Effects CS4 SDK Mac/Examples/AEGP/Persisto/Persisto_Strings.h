// Persisto_Strings.h

#pragma once

typedef enum {
	StrID_NONE, 
	StrID_Name,
	StrID_Settings,
	StrID_Fuzziness,
	StrID_NewValueAdded,
	StrID_ValueExisted,
	StrID_NewValueSet,
	StrID_Cliche,
	StrID_OneButton,
	StrID_Troubles,
	StrID_Description,
	StrID_Color_Param_Name,
	StrID_Checkbox_Param_Name,	
	StrID_Checkbox_Description,
	StrID_DependString1,
	StrID_DependString2,
	StrID_Err_LoadSuite,
	StrID_Err_FreeSuite,
	StrID_3D_Param_Name,
	StrID_3D_Param_Description,
	StrID_No_Comp,
	StrID_NUMTYPES
} StrIDType;

