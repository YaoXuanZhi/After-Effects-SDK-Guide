/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

#include <string>
#include <vector>
#include "PT_Err.h"
#include "PanelatorUI_Plat.h"
#include <limits>

#define kClickMePressed		'CLik'
#define	kMenuAboutToShow	kEventMenuPopulate

OSStatus PanelatorUI_Plat::S_EventHandler(EventHandlerCallRef myHandler, EventRef event, void *userData)
{
	return reinterpret_cast<PanelatorUI_Plat*>(userData)->EventHandler(myHandler, event);
}


PanelatorUI_Plat::PanelatorUI_Plat(SPBasicSuite* spbP, AEGP_PanelH panelH, 
							AEGP_PlatformViewRef platformViewRef,
							AEGP_PanelFunctions1* outFunctionTable) : PanelatorUI( spbP, panelH, platformViewRef, outFunctionTable)
{
	OSStatus	err = noErr;
	
	#define	kViewEventTableSize	(sizeof(kViewEventTable) / sizeof(EventTypeSpec))
    static const EventTypeSpec  kViewEventTable[] = {
		{ kEventClassControl,	kEventControlDraw	}
	};
	
	PT_ERR(InstallEventHandler(
		GetControlEventTarget(i_refH), // 6
		NewEventHandlerUPP (S_EventHandler), 
		kViewEventTableSize, 
		kViewEventTable, 
		(void *) this, NULL)); 

	/****************************************************************/
	Rect buttonRect = {200, 10,230,100 };


	ControlRef newControl;
	err = CreatePushButtonControl (NULL,  &buttonRect,   CFSTR("Click Me!"),  &newControl);
    err = HIViewAddSubview(i_refH, newControl);
	
	SetControlCommandID(newControl, kClickMePressed);
 
	#define	kClickEventTableSize	(sizeof(kClickEventTable) / sizeof(EventTypeSpec))
	static const EventTypeSpec  kClickEventTable[] = {
		{ kEventClassCommand,	kEventProcessCommand	}
	};
	
	err = InstallEventHandler(
		GetControlEventTarget(newControl), // 6
		NewEventHandlerUPP (S_EventHandler), 
		kClickEventTableSize, 
		kClickEventTable, 
		(void *)this, NULL); 
										
	/*********************************************************************/
	#define		kPopupTitleString		CFSTR("Primary Format: ")
	#define		kSpecifyMenuRefLater	-12345
	#define		kMyPopMenuID			2002
	Rect		menuRect = {5, 33, 25, 407 };
	
	PT_ERR(CreateNewMenu(kMyPopMenuID, 0, &m_hPrimaryControlMenuRef));
	PT_ERR(SetMenuTitleWithCFString(m_hPrimaryControlMenuRef, kPopupTitleString));

	PT_ERR(CreatePopupButtonControl(
		NULL, &menuRect, kPopupTitleString, kSpecifyMenuRefLater,
		false, 100, teFlushRight, normal, &m_hPrimaryControl));

	PT_ERR(SetControlCommandID(m_hPrimaryControl, 'XP30'));		//	un-necessary?
	
	PT_ERR(SetControlData(
		m_hPrimaryControl, 
		kControlEntireControl,
		kControlPopupButtonMenuRefTag, 
		sizeof(MenuRef),
		&m_hPrimaryControlMenuRef));

	#define	kPopupEventTableSize	(sizeof(kPopupEventTable) / sizeof(EventTypeSpec))
 	static const EventTypeSpec  kPopupEventTable[] = {
		{ kEventClassMenu,		kEventMenuPopulate		},
		{ kEventClassCommand,	kEventProcessCommand	}
	};
	
	PT_ERR(InstallEventHandler(
		GetControlEventTarget(m_hPrimaryControl), 
		NewEventHandlerUPP(S_EventHandler),		//	shouldn't we just use the one we just made above?
		kPopupEventTableSize, 
		kPopupEventTable, 
		(void *)this, NULL));
								
	PT_ERR(HIViewAddSubview(i_refH, m_hPrimaryControl));

	if (!err) {
		UpdateMenu();
		SetControlValue(m_hPrimaryControl, (SInt16)(1));
	}
	
	//	shouldn't we cleanup and throw if we get an error??
}


void SetColorFromSelector(CGContextRef theContext, PFAppSuite2* appSuiteP, PF_App_ColorType sel)
{
	PF_App_Color	appColor = {0};
	// mmmm. old quickdraw style color
	appSuiteP->PF_AppGetColor(sel, &appColor);
    CGContextSetRGBFillColor(
		theContext, 
		static_cast<float>(appColor.red)	/ static_cast<float>(std::numeric_limits<A_u_short>::max()),
		static_cast<float>(appColor.green)	/ static_cast<float>(std::numeric_limits<A_u_short>::max()), 
		static_cast<float>(appColor.blue)	/ static_cast<float>(std::numeric_limits<A_u_short>::max()),
		1.0);
}

class CUpdateMenu {
	MenuRef		i_menuRef;
	
	public:
	CUpdateMenu(MenuRef menuRef) : i_menuRef(menuRef) {
		PT_ETX(DeleteMenuItems(i_menuRef, 1, CountMenuItems(i_menuRef)));
	}
	
	void	operator()(const AEGP_FlyoutMenuItem& itemRef) {
		OSStatus		err			= noErr;
		CFStringRef		itemStrRef	= NULL;
		
		if (itemRef.type == AEGP_FlyoutMenuMarkType_SEPARATOR) {
			itemStrRef = CFSTR("-");
			CFRetain(itemStrRef);
		} else {
			itemStrRef = CFStringCreateWithCString(
				NULL, (char *)itemRef.utf8NameZ, kCFStringEncodingUTF8);
		}
		
		PT_ETX(itemStrRef == NULL ? (OSStatus)memFullErr : (OSStatus)noErr);

		PT_ERR(AppendMenuItemTextWithCFString(
			i_menuRef, 
			itemStrRef, 
			(MenuItemAttributes)itemRef.cmdID == AEGP_FlyoutMenuCmdID_NONE ? kMenuItemAttrDisabled : 0, 
			itemRef.cmdID, 
			NULL));

		CFRelease(itemStrRef);
		PT_ETX(err);
	}
};

OSStatus	PanelatorUI_Plat::UpdateMenu()
{
	OSStatus								err			= noErr;
	A_long									vecSizeL	= 10;	//	should be a konstant
	std::vector<AEGP_FlyoutMenuItem>		menuVec(vecSizeL);
	
	//	i'm re-using the flyout menu but you would have your own menu list at this point
	PopulateFlyout(&menuVec[0], &vecSizeL);
	PT_XTE(std::for_each(menuVec.begin(), menuVec.end(), CUpdateMenu(m_hPrimaryControlMenuRef)));
	SetControlMaximum(m_hPrimaryControl, CountMenuItems(m_hPrimaryControlMenuRef));
	return noErr;
}

OSStatus	PanelatorUI_Plat::DrawPanelBackground(CGContextRef myContext)
{
	HIRect			clientArea;
	
	//	check for errs thru this whole function??
	HIViewGetBounds(i_refH, &clientArea);

	// ********** Your drawing code here ********** 

	if (i_use_bg) {
		SetColorFromSelector(myContext, i_appSuite.get(), PF_App_Color_PANEL_BACKGROUND);
	} else {
		CGContextSetRGBFillColor(myContext, red/255.0, green/255.0, blue/255.0, 1.0);
	}

	CGContextFillRect(myContext, clientArea);

	clientArea.size.width = 200;
	clientArea.size.height = 30;
	SetColorFromSelector(myContext, i_appSuite.get(), PF_App_Color_LIST_BOX_FILL);
	CGContextFillRect(myContext, clientArea);

	clientArea.origin.y += clientArea.size.height;
	SetColorFromSelector(myContext, i_appSuite.get(), PF_App_Color_TEXT_ON_LIGHTER_BG);
	CGContextFillRect(myContext, clientArea);

	clientArea.origin.y += clientArea.size.height;
	SetColorFromSelector(myContext, i_appSuite.get(), PF_App_Color_DARK_CAPTION_FILL);
	CGContextFillRect(myContext, clientArea);

	clientArea.origin.y += clientArea.size.height;
	SetColorFromSelector(myContext, i_appSuite.get(), PF_App_Color_DARK_CAPTION_TEXT);
	CGContextFillRect(myContext, clientArea);


	char textToDraw[200];
	HIRect      origClientArea;
	HIViewGetBounds(i_refH, &origClientArea);

	SetColorFromSelector(myContext, i_appSuite.get(), PF_App_Color_TEXT_ON_LIGHTER_BG);

	sprintf(textToDraw, "Size: %f, %f", origClientArea.size.width, origClientArea.size.height);
	clientArea.origin.y += clientArea.size.height + 14;
			
	// text is upside down?
	CGAffineTransform transform = CGAffineTransformIdentity;
	transform.d = -1.0;
	CGContextSetTextMatrix(myContext, transform); 
	CGContextSelectFont(myContext, "Helvetica", 12,  kCGEncodingMacRoman);
	CGContextShowTextAtPoint(myContext, clientArea.origin.x, clientArea.origin.y,  textToDraw, strlen(textToDraw));
			
	sprintf(textToDraw, "NumClicks: %d", i_numClicks);
	clientArea.origin.y += clientArea.size.height;

	CGContextShowTextAtPoint(myContext, clientArea.origin.x, clientArea.origin.y,  textToDraw, strlen(textToDraw));

	return noErr;
}


OSStatus  PanelatorUI_Plat::EventHandler(EventHandlerCallRef myHandler, EventRef eventRef)
{
	OSStatus	err			= noErr;
	bool		handledB	= false;
	UInt32      eventClass	= GetEventClass(eventRef);
	UInt32      eventKind	= GetEventKind(eventRef);
	
	switch (eventClass) {

		case kEventClassMenu: {
			
			switch (eventKind) {
				
				case kEventMenuPopulate: {
					//	UpdateMenu();		//	only if the menu is going to change or update it's check marks etc
					break;
				}
			}
			break;
		}
		
		case kEventClassCommand: {
			HICommand      hiCommand;
		  
			PT_ERR(GetEventParameter(
				eventRef, 
				kEventParamDirectObject, 
				typeHICommand, 
				NULL, sizeof(HICommand), 
				NULL, &hiCommand));
			
			switch (eventKind) {
				
				case kEventProcessCommand: {

					switch (hiCommand.commandID) {

						case PT_MenuCmd_RED:
						case PT_MenuCmd_GREEN:
						case PT_MenuCmd_BLUE:
						case PT_MenuCmd_STANDARD:
						case PT_MenuCmd_TITLE_LONGER:
						case PT_MenuCmd_TITLE_SHORTER: {
							DoFlyoutCommand(hiCommand.commandID);
							handledB = true;
							break;
						}

						case kClickMePressed: {
							i_numClicks++;
							InvalidateAll();
							handledB = true;
							break;
						}
					}
					break;
				}
			}
			
			break;
		}
		
		case kEventClassControl: {
		
			switch (eventKind) {

				case kEventControlDraw: {
					CGContextRef	myContext = NULL;

					PT_ERR(GetEventParameter(
						eventRef, 
						kEventParamCGContextRef, 
						typeCGContextRef, 
						NULL, sizeof(CGContextRef), NULL,
						&myContext));
					
					//	check for err??

					PT_ERR(DrawPanelBackground(myContext));
					handledB = true;
					break;
				}
			}
			
			break;
		}
	}
	
	if (!handledB) {
		PT_ERR(eventNotHandledErr);
	}

    return err;
}
	
void PanelatorUI_Plat::InvalidateAll() 
{
	HIViewSetNeedsDisplay(i_refH, true);
}