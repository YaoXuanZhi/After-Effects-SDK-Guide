/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

/*
	Portable.cpp

	This sample demonstrates how to detect (and, to a slight
	extent, respond to) different hosts.
	
	Revision History
		1.0		Created for use in Premiere AE API support testing 		bbb
		2.0		Put on some weight. In a good way.						bbb
		
*/

#include "Portable.h"

static PF_Err 
About (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PF_SPRINTF(	out_data->return_msg, 
				"%s, v%d.%d\r%s",
				STR(StrID_Name), 
				MAJOR_VERSION, 
				MINOR_VERSION, 
				STR(StrID_Description));

	return PF_Err_NONE;
}

static PF_Err 
AllocateGlobalsTheOldWay (	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{
	PF_Err		err					= PF_Err_NONE;
	PF_Handle	sample_global_dataH = PF_NEW_HANDLE(sizeof(A_long));

	if (!sample_global_dataH){
		err = PF_Err_OUT_OF_MEMORY;
	} else {
		A_long *tempP = static_cast<A_long*>(PF_LOCK_HANDLE(sample_global_dataH));
		if (!tempP){
			err = PF_Err_OUT_OF_MEMORY;
		} else {
			*tempP = in_data->appl_id;
			PF_UNLOCK_HANDLE(sample_global_dataH);
		}
	}
	return err;
}

static PF_Err 
AllocateGlobalsTheNewWay (	
	PF_InData		*in_data,
	PF_OutData		*out_data)
{
	AEGP_SuiteHandler suites(in_data->pica_basicP);

	//	NOTE: Just because we're using the old AE API
	//	doesn't mean we aren't using the exception-throwing
	//	AEGP_SuiteHandler class. Old APIs don't necessitate
	//	old code.
	
	PF_Err		err					= PF_Err_NONE;
	PF_Handle	sample_global_dataH = suites.HandleSuite1()->host_new_handle(sizeof(A_long));

	//	Takes advantage of new-fangled memory plumbing, and heck, isn't newer ALWAYS better?! 
	//	(No, it's not, but hey, it's a sample)

	if (!sample_global_dataH){
		err = PF_Err_OUT_OF_MEMORY;
	} else {
		A_long *host_idPL = static_cast<A_long*>(suites.HandleSuite1()->host_lock_handle(sample_global_dataH));
		if (!host_idPL){
			err = PF_Err_INVALID_CALLBACK;
		} else {
			*host_idPL = in_data->appl_id;
		}
	}
	suites.HandleSuite1()->host_unlock_handle(sample_global_dataH);
	return err;
}

static PF_Err 
GlobalSetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PF_Err		err					= PF_Err_NONE;

	out_data->my_version = PF_VERSION(	MAJOR_VERSION, 
										MINOR_VERSION,
										BUG_VERSION, 
										STAGE_VERSION, 
										BUILD_VERSION);
	
	out_data->out_flags |=	PF_OutFlag_PIX_INDEPENDENT |
							PF_OutFlag_USE_OUTPUT_EXTENT;

	return err;
}

static PF_Err 
ParamsSetup (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PF_Err			err = PF_Err_NONE;
	PF_ParamDef		def;
	AEFX_CLR_STRUCT(def);

	PF_ADD_FIXED(	"Slider", 
					PORTABLE_MIN, 
					PORTABLE_BIG_MAX, 
					PORTABLE_MIN, 
					PORTABLE_MAX, 
					PORTABLE_DFLT,
					1, 
					0,
					0,
					PORTABLE_DISK_ID);

	out_data->num_params = PORTABLE_NUM_PARAMS;

	return err;
}


static PF_Err 
SequenceSetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PORTABLE_Table	*g_tableP	=	NULL;
	PF_Err			err			=	PF_Err_NONE;

	switch (in_data->appl_id){
		
		case 'PrMr':
			{
				if (in_data->version.major == 12 && in_data->version.minor == 4)
				{
					PF_SPRINTF(out_data->return_msg, "Hey, Premiere Pro 3.0! Neat.");
				}
				else if (in_data->version.major == 12 && in_data->version.minor == 3)
				{
					PF_SPRINTF(out_data->return_msg, "Hey, Premiere Pro 2.0 or Premiere Elements 3.0! Neat.");
				}
				else if (in_data->version.major == 12 && in_data->version.minor == 2)
				{
					PF_SPRINTF(out_data->return_msg, "Hey, Premiere Pro 1.5 or Premiere Elements 2.0! Neat.");
				}
				else if (in_data->version.major == 12 && in_data->version.minor == 1)
				{
					PF_SPRINTF(out_data->return_msg, "Hey, Premiere Pro 1.0 or Premiere Elements 1.0! Neat.");
				}
				else if (in_data->version.major == 12 && in_data->version.minor > 4)
				{
					PF_SPRINTF(out_data->return_msg, "Hey, some new version of Premiere!");
				}
				else
				{
					PF_SPRINTF(out_data->return_msg, "Hey, some unknown version of Premiere!");
				}
			}
			break;

		case 'KeyG':
			PF_SPRINTF(out_data->return_msg, "Hey, Final Cut! Neat.");
			break;

		case 'Cbst':
			PF_SPRINTF(out_data->return_msg, "Hey, Combustion! Neat.");
			//	Many thanks to developer Robert Graf robert@goofers.org,
			//	for saving me the trouble of rigging up a Combustion-based
			//	debugging session just to find the appl_id.
			//						-bbb 07/13/06
			break;
			
		case 'FXTC':
			if (in_data->version.major < 12){	// Wow, an antique!
				
				ERR(AllocateGlobalsTheOldWay(in_data,out_data));
				//	DisplayWarningAboutUsingPluginInOldHost();
				//	SuggestUpgradingAESoYourPluginGetsNewAPIFeatures();
				
			} else {
				ERR(AllocateGlobalsTheNewWay(in_data, out_data));
				
				//	Q. How can I tell the difference between AE 6.5 and 7.0?
				
				//	A. The effect API didn't change the only way to differentiate
				//	between them is to check for the presence of a version of a 
				//	suite new in 7.0. Say, something 32bpc-ish. To avoid AEGP_SuiteHandler
				//	throwing if	the suite isn't present, we'll acquire it the old-school way.
				
				PF_iterateFloatSuite1 *ifsP = NULL;
				
				PF_Err just_checking_err = AEFX_AcquireSuite(	in_data, 
																out_data, 
																kPFIterateFloatSuite, 
																kPFIterateFloatSuiteVersion1, 
																NULL, 
																reinterpret_cast<void**>(&ifsP));
				if (!just_checking_err){
					if (!ifsP){
						PF_SPRINTF(out_data->return_msg, "Running in After Effects 6.5 or earlier.");
					} else {
						PF_SPRINTF(out_data->return_msg, "Running in After Effects 7.0 or later.");
					}

					//	Thanks, you have your suite back...
					
					just_checking_err = AEFX_ReleaseSuite(in_data, 
														  out_data, 
														  kPFIterateFloatSuite, 
														  kPFIterateFloatSuiteVersion1,
														  NULL);
				}
			}
			break;
		default:
			PF_SPRINTF(out_data->return_msg, "Wow, we're running in some oddball host.");
			break;
	}

	if (in_data->sequence_data){
		PF_DISPOSE_HANDLE(in_data->sequence_data);
	}
	out_data->sequence_data = PF_NEW_HANDLE(sizeof(PORTABLE_Table));
	if (!out_data->sequence_data) {
		err = PF_Err_OUT_OF_MEMORY;
	}

	// generate base table

	if (!err){
		g_tableP = *(PORTABLE_Table**)out_data->sequence_data;
		g_tableP->PORTABLE_val = (1L << 16);

		for (A_long iL = 0; iL <= PF_MAX_CHAN8; iL++){
			g_tableP->lut[iL] = (A_u_char)iL;
		}
	}
	return PF_Err_NONE;
}

static PF_Err 
SequenceSetdown (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	if (in_data->sequence_data) {
		PF_DISPOSE_HANDLE(in_data->sequence_data);
		out_data->sequence_data = NULL;
	}
	return PF_Err_NONE;
}


static PF_Err 
SequenceResetup (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PF_Err err = PF_Err_NONE;
	
	if (!in_data->sequence_data) {
		ERR(SequenceSetup(in_data, out_data, params, output));
	}
	
	return err;
}

// Computes the gamma-corrected pixel given the lookup table.

static PF_Err 
GammaFunc (	
	A_long refcon, 
	A_long x, 
	A_long y, 
	PF_Pixel *inP, 
	PF_Pixel *outP)
{
	PF_Err		err = PF_Err_NONE;
	GammaInfo	*giP = (GammaInfo*)refcon;	
	
	if (giP){
		outP->alpha	= inP->alpha;
		outP->red	= giP->lut[ inP->red 	];
		outP->green	= giP->lut[ inP->green 	];
		outP->blue	= giP->lut[ inP->blue 	];
	} else {
		err = PF_Err_BAD_CALLBACK_PARAM;
	}
	return err;
}

static PF_Err 
Render (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{
	PF_Err			err			 		= PF_Err_NONE;
	PORTABLE_Table	*g_tableP			= NULL;
	GammaInfo		PORTABLE_info;
	
	AEFX_CLR_STRUCT(PORTABLE_info);
	
	// If the gamma factor is exactly 1.0 just make a direct copy.
	
	if (params[PORTABLE_SLIDER]->u.fd.value == (1L << 16)) {
		ERR(PF_COPY(&params[0]->u.ld, 
					output, 
					NULL, 
					NULL));
	} else {
		 
		// If no table exists, pop an error message.

		if (!out_data->sequence_data) {
			PF_STRCPY(out_data->return_msg, "Portable invoked without lookup table");
			out_data->out_flags |= PF_OutFlag_DISPLAY_ERROR_MESSAGE;
			err = PF_Err_INVALID_CALLBACK;
		} else if (!err){
			g_tableP = *(PORTABLE_Table**)out_data->sequence_data;
		
			if (g_tableP->PORTABLE_val != params[PORTABLE_SLIDER]->u.fd.value) {
			
				// if the table values are bad, regenerate table contents.
				 
				register PF_FpLong	temp 	= 0,
									gamma	= 0;

				g_tableP->PORTABLE_val	= params[PORTABLE_SLIDER]->u.fd.value;
				gamma					= g_tableP->PORTABLE_val / (PF_FpLong)(1L << 16);
				gamma					= 1.0 / gamma;
				
				for (register A_long xL = 0; xL <= 255; ++xL) {
					temp = PF_POW((PF_FpLong)xL / 255.0, gamma);
					g_tableP->lut[xL] = (A_u_char)(temp * 255.0);
				}
			}
			
			// clear all pixels outside extent_hint.

			if (in_data->extent_hint.left	!=	output->extent_hint.left	||
				in_data->extent_hint.top	!=	output->extent_hint.top		||
				in_data->extent_hint.right	!=	output->extent_hint.right	||
				in_data->extent_hint.bottom	!=	output->extent_hint.bottom) {
		
				ERR(PF_FILL(NULL, &output->extent_hint, output));
			}
		}
		if (!err) {
		
			// iterate over image data.

			register A_long progress_heightL = in_data->extent_hint.top - in_data->extent_hint.bottom;
			PORTABLE_info.lut = g_tableP->lut;
			
			ERR(PF_ITERATE(	0, 
							progress_heightL,
							&params[PORTABLE_INPUT]->u.ld, 
							&in_data->extent_hint,
							(long)&PORTABLE_info, 
							GammaFunc, 
							output));
		}
	}
	return err;
}

DllExport	
PF_Err EntryPointFunc(
	PF_Cmd			cmd,
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	void			*extra)
{
	PF_Err		err = PF_Err_NONE;
	
	switch (cmd) {
		case PF_Cmd_ABOUT:
			err = About(in_data,out_data,params,output);
			break;
		case PF_Cmd_GLOBAL_SETUP:
			err = GlobalSetup(in_data,out_data,params,output);
			break;
		case PF_Cmd_PARAMS_SETUP:
			err = ParamsSetup(in_data,out_data,params,output);
			break;
		case PF_Cmd_SEQUENCE_SETUP:
			err = SequenceSetup(in_data,out_data,params,output);
			break;
		case PF_Cmd_SEQUENCE_SETDOWN:
			err = SequenceSetdown(in_data,out_data,params,output);
			break;
		case PF_Cmd_SEQUENCE_RESETUP:
			err = SequenceResetup(in_data,out_data,params,output);
			break;
		case PF_Cmd_RENDER:
			err = Render(in_data,out_data,params,output);
			break;
	}
	return err;
}

