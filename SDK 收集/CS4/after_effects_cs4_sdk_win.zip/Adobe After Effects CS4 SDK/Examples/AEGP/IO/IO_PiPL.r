#include "AEConfig.h"

#ifndef AE_OS_WIN
	#include "AE_General.r"
#endif

resource 'PiPL' (16000) {
	{	/* array properties: 7 elements */
		/* [1] */
		Kind {
			AEGP
		},
		/* [2] */
		Name {
			"SDK_IO"
		},
		/* [3] */
		Category {
			"General Plugin"
		},
		/* [4] */
		Version {
			65536
		},
		/* [5] */
#ifdef AE_OS_WIN
		CodeWin32X86 {
			"GPMain_IO"
		},
#else	
	#ifdef AE_OS_MAC
		CodeMachOPowerPC {
			"GPMain_IO"
		},
		CodeMacIntel32 {
			"GPMain_IO"
		},
	#endif
#endif
	}
};

