#pragma once

typedef enum {
	StrID_NONE,							
	StrID_Name,							
	StrID_Description,					
	StrID_ADM_PALETTE_LEFT_OFFSET,		
	StrID_ADM_PALETTE_TOP_OFFSET,		
	StrID_ADM_PALETTE_RBN_HEIGHT,		
	StrID_ADM_PALETTE_RBN_OFFSET,		
	StrID_ADM_PALETTE_POPUP_OFFSET,		
	StrID_ADM_PALETTE_BTN_HEIGHT,		
	StrID_ADM_PALETTE_POPUP_HEIGHT,		
	StrID_ADM_PALETTE_TXT_HEIGHT,		
	StrID_ADM_PALETTE_EDIT_HEIGHT,		
	StrID_ADM_PALETTE_CBX_OFFSET,		
	StrID_ADM_PALETTE_CBX_HEIGHT,		
	StrID_ADM_PALETTE_TXT_OFFSET,		
	StrID_ADM_PALETTE_DIVIDER_HEIGHT,
	StrID_SuiteError,
	StrID_InitError,
	StrID_AddCommandError,
	StrID_UndoError,
	StrID_URL,
	StrID_Tagline,
	StrID_MessedUpLayerName,
	StrID_MessedUpMaskName,
	StrID_NUMTYPES
} StrIDType;

