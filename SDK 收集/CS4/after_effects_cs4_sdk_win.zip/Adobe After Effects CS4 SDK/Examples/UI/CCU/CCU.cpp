/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

/*
	CCU.cpp
	
	Part of the Adobe After Effects 8.0 SDK.
	Copyright 2007 Adobe Systems Incorporated.
	All Rights Reserved.
	
	Revision History

		1.0, 	created 			dmw		(lost in the mists of time...)
		2.0		ported to C++		bbb		3/20/02
*/

#include "CCU.h"


static PF_Err 
About (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output)
{
	const unsigned char msg[256] = "poop";
	DebugStr(msg);
	AEGP_SuiteHandler suites(in_data->pica_basicP);

	suites.ANSICallbacksSuite1()->sprintf(out_data->return_msg,
								"%s v%d.%d\r%s",
								STR(StrID_Name), 
								MAJOR_VERSION, 
								MINOR_VERSION, 
								STR(StrID_Description));

	return PF_Err_NONE;
}

static PF_Err 
GlobalSetup (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output)
{
	out_data->out_flags |=	PF_OutFlag_USE_OUTPUT_EXTENT 	|
							PF_OutFlag_PIX_INDEPENDENT 		|
							PF_OutFlag_CUSTOM_UI;

	out_data->my_version = PF_VERSION(	MAJOR_VERSION, 
										MINOR_VERSION,
										BUG_VERSION, 
										STAGE_VERSION, 
										BUILD_VERSION);
	return PF_Err_NONE;
}

static PF_Err 
ParamsSetup (	
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output)
{
	PF_Err 			err = PF_Err_NONE;
	PF_ParamDef		def;
	
	AEFX_CLR_STRUCT(def);

	PF_ADD_FIXED(	STR(StrID_X_Slider_Name), 
					CCU_RADIUS_MIN, 
					CCU_RADIUS_BIG_MAX, 
					CCU_RADIUS_MIN, 
					CCU_RADIUS_MAX, 
					CCU_RADIUS_DFLT, 
					SLIDER_PRECISION, 
					DISPLAY_FLAGS,
					0,
					X_SLIDER_DISK_ID);

	AEFX_CLR_STRUCT(def);
	
	PF_ADD_FIXED(	STR(StrID_Y_Slider_Name), 
					CCU_RADIUS_MIN, 
					CCU_RADIUS_BIG_MAX, 
					CCU_RADIUS_MIN, 
					CCU_RADIUS_MAX, 
					CCU_RADIUS_DFLT, 
					SLIDER_PRECISION, 
					DISPLAY_FLAGS,
					0,
					Y_SLIDER_DISK_ID);

	AEFX_CLR_STRUCT(def);

	PF_ADD_POINT(	STR(StrID_Center_Name), 
					CCU_PTX_DFLT, 
					CCU_PTY_DFLT, 
					RESTRICT_BOUNDS,
					CENTER_DISK_ID);

	AEFX_CLR_STRUCT(def);	

	if (!err) 
	{
		PF_CustomUIInfo			ci;
		
		AEFX_CLR_STRUCT(ci);
		
		ci.events				=	PF_CustomEFlag_LAYER | 
									PF_CustomEFlag_COMP;
 		ci.comp_ui_width		= 
		ci.comp_ui_height		=	0;
		
		ci.comp_ui_alignment	=	PF_UIAlignment_NONE;
		
		ci.layer_ui_width		= 
		ci.layer_ui_height		=	0;
		
		ci.layer_ui_alignment	=	PF_UIAlignment_NONE;
		
		ci.preview_ui_width		=	
		ci.preview_ui_height	=	0;
		
		ci.layer_ui_alignment	=	PF_UIAlignment_NONE;

		err = (*(in_data->inter.register_ui))(in_data->effect_ref, &ci);
	}
	
	out_data->num_params		= CCU_NUM_PARAMS;
	
	return err;
}

static PF_Err 
Render (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*outputP)
{
	PF_Err 				err = PF_Err_NONE;

	AEGP_SuiteHandler	suites(in_data->pica_basicP);

	PF_EffectWorld		*inputP 		= &params[0]->u.ld;

	A_long				min_xL			= 	outputP->extent_hint.left, 
						max_xL			= 	outputP->extent_hint.right, 
						min_yL			= 	outputP->extent_hint.top, 
						max_yL			= 	outputP->extent_hint.bottom,
						in_gutterL		= 	(inputP->rowbytes / sizeof(PF_Pixel8)) - inputP->width,
						out_gutterL		=	(outputP->rowbytes / sizeof(PF_Pixel8)) - outputP->width;

	PF_Pixel8			*bop_outP		= 	outputP->data,
						*bop_inP		= 	inputP->data;
											
	PF_FpLong			rad_xF			= 	FIX_2_FLOAT(params[CCU_X_RADIUS]->u.fd.value), 
						rad_yF			= 	FIX_2_FLOAT(params[CCU_Y_RADIUS]->u.fd.value), 
						center_xF		= 	FIX_2_FLOAT(params[CCU_PT]->u.td.x_value), 
						center_yF		= 	FIX_2_FLOAT(params[CCU_PT]->u.td.y_value), 
						distF			=	0,	
						dxF				=	0, 
						dyF				=	0, 
						dy_sqrF			=	0,
						rad_xF_invF		= 	1.0 / rad_xF,
						y_ratioF		= 	rad_yF * rad_xF_invF,
						y_ratio_invF	= 	1.0 / y_ratioF,
						inv_parF		=	1.0;

	// inflict the downsample factor on the circle radius
	
	rad_xF	/= in_data->downsample_x.den;
	rad_yF	/= in_data->downsample_y.den;
	rad_xF	*= in_data->downsample_x.num;
	rad_yF	*= in_data->downsample_y.num;

	// Calculate pixel aspect ratio, save the inverse

	inv_parF = in_data->pixel_aspect_ratio.den / in_data->pixel_aspect_ratio.num;

	// If either width or height is 0, just copy the input
	
	if (rad_xF == 0 || rad_yF == 0) {
		if (PF_Quality_HI == in_data->quality){
			return suites.WorldTransformSuite1()->copy_hq(	in_data->effect_ref,
															&params[0]->u.ld, 
															outputP, 
															NULL, 
															NULL);
		} else{
			return suites.WorldTransformSuite1()->copy(	in_data->effect_ref,
														&params[0]->u.ld, 
														outputP, 
														NULL, 
														NULL);
		}
	} else {
		for (register A_long yL = 0; yL < outputP->height ; yL++) {

			dyF		= 	static_cast<PF_FpLong>(yL - center_yF);
			dy_sqrF	= 	dyF * y_ratio_invF;	/* convert to be rad_xF relative */
			dy_sqrF	*= 	dy_sqrF;

			if (dyF > rad_yF 	|| 
				dyF < -rad_yF 	|| 
				yL < min_yL 	|| 
				yL > max_yL) {
				
				for (register A_long xL = outputP->width; xL > 0; xL--)	{
					*bop_outP++ = *bop_inP++;
				}
					
			} else {
				for (register A_long xL = 0; xL < inputP->width; xL++) {
					dxF = xL - center_xF;
					
					dxF *= inv_parF;
					if (dxF > rad_xF || dxF < -rad_xF || xL < min_xL || xL > max_xL) {
						*bop_outP++ = *bop_inP++;
						continue;
					}
				
					distF = suites.ANSICallbacksSuite1()->sqrt(dxF * dxF + dy_sqrF);

					// if the distance is zero, or if the pixel is
					// outside the circle's radius, just copy the
					// source.
					
					if (distF == 0 || distF >= rad_xF) {
						*bop_outP++ = *bop_inP++;
						continue;
					} else {
						bop_outP->alpha = 	bop_inP->alpha;
						bop_outP->green	=	PF_MAX_CHAN8;
						bop_outP->blue 	= 	0;
						bop_outP->red 	= 	0;
					}
					bop_inP++;	
					bop_outP++;
				}
			}

			// at the end of each row, account for the gutter
			// (this number can vary by platform and for other
			// reasons).
			
			if (yL >= 0 && yL < inputP->height){
				bop_inP	+= in_gutterL;
			}
		
			bop_outP += out_gutterL;

			// check for interrupt!
			if ((yL) && (err = PF_PROGRESS(in_data, yL + 1, outputP->height))){
				return err;
			}
		} 
	}
	return err;
}

static void 
CCU_ConcatMatrix (
				  const	PF_FloatMatrix	*src_matrixP,
				  PF_FloatMatrix	*dst_matrixP)
{
	PF_FloatMatrix	tmp;
	
 	PF_FpLong	tempF 	=	0;
	
   	for (register A_long iL = 0; iL < 3; iL++) {
   		for (register A_long jL = 0; jL < 3; jL++) {
			tempF =	dst_matrixP->mat[iL][0] * src_matrixP->mat[0][jL] +
			dst_matrixP->mat[iL][1] * src_matrixP->mat[1][jL] +
			dst_matrixP->mat[iL][2] * src_matrixP->mat[2][jL];
			
 		 	tmp.mat[iL][jL] = tempF;
		}
	}
	*dst_matrixP = tmp;
}

void 
CCU_SetIdentityMatrix (
	PF_FloatMatrix *matrixP)
{
	matrixP->mat[0][0] = 
	matrixP->mat[1][1] = 
	matrixP->mat[2][2] = 1;	
	
	matrixP->mat[0][1] = 
	matrixP->mat[0][2] =
	matrixP->mat[1][0] = 
	matrixP->mat[1][2] =
	matrixP->mat[2][0] = 
	matrixP->mat[2][1] = 0;
}

PF_Err 
CCU_ScaleMatrix (
	PF_FloatMatrix 	*mP,		
	PF_FpLong 		scaleX,		
	PF_FpLong 		scaleY,		
	PF_FpLong 		aboutX,		
	PF_FpLong 		aboutY )		
{
	PF_Err			err = PF_Err_NONE;

	PF_FloatMatrix	scale;
	
	if (scaleX != 1.0 || scaleY != 1.0) 
	{
	
		scale.mat[0][0] = scaleX; 	
		scale.mat[0][1] = 0; 			
		scale.mat[0][2] = 0;
		
		scale.mat[1][0] = 0;		
		scale.mat[1][1] = scaleY;
		scale.mat[1][2] = 0;
	
		scale.mat[2][0] = (1.0 - scaleX) * (aboutX);
		scale.mat[2][1] = (1.0 - scaleY) * (aboutY);
		scale.mat[2][2] = 1;	
	
		CCU_ConcatMatrix(&scale, mP);
	}
	return err;
}

PF_Err 
CCU_RotateMatrixPlus (
	PF_FloatMatrix	*matrixP,
	PF_InData		*in_data,
	PF_FpLong		degreesF,
	PF_FpLong		aboutXF,	
	PF_FpLong		aboutYF)
{
	AEGP_SuiteHandler	suites(in_data->pica_basicP);
	
	PF_Err			err 		= PF_Err_NONE;

	PF_FloatMatrix	rotate;

	PF_FpLong		radiansF	=	0, 
					sF	 		= 	0, 
					cF	 		= 	0;
	
	if (degreesF){
		radiansF 	=  	PF_RAD_PER_DEGREE * degreesF;
		sF			= 	suites.ANSICallbacksSuite1()->sin(radiansF);
		cF			= 	suites.ANSICallbacksSuite1()->cos(radiansF);
	
		rotate.mat[0][0] =	cF; 
		rotate.mat[0][1] =	sF; 
		rotate.mat[0][2] =	0;
		
		rotate.mat[1][0] =	-sF; 
		rotate.mat[1][1] =	cF; 
		rotate.mat[1][2] =	0;
		
		rotate.mat[2][0] =	(aboutXF * (1.0 - cF) + aboutYF * sF);	
		rotate.mat[2][1] =	(aboutYF * (1.0 - cF) - aboutXF * sF);
		rotate.mat[2][2] =	1;
		
		CCU_ConcatMatrix(&rotate, matrixP);
	}
	return err;
}

void 
CCU_TransformFixPoints (
	const	PF_FloatMatrix	*matrixP,
			A_long			countL,
			PF_FixedPoint	*pointsFiAP)
{
	PF_Fixed			iL 				= 	0;
	PF_FixedPoint		currentFiPt		=	{0,0};
	PF_FpLong			dF 				= 	0;

	for (iL = 0; iL < countL; iL++) 
	{
	
		currentFiPt	= pointsFiAP[iL];

		dF		=	currentFiPt.x * matrixP->mat[0][0] + 
					currentFiPt.y * matrixP->mat[1][0] + 
					65536.0 * 
					matrixP->mat[2][0];
		
		pointsFiAP[iL].x	= 	static_cast<PF_Fixed>(ROUND_DBL2LONG(dF));
		
		dF		 			=	currentFiPt.x * matrixP->mat[0][1] + 
								currentFiPt.y * 
								matrixP->mat[1][1] +  
								65536.0 * 
								matrixP->mat[2][1];

		pointsFiAP[iL].y	=	static_cast<PF_Fixed>(ROUND_DBL2LONG(dF));
	}
}

PF_Err DllExport 
EntryPointFunc (
				PF_Cmd			cmd,
				PF_InData		*in_data,
				PF_OutData		*out_data,
				PF_ParamDef		*params[],
				PF_LayerDef		*output,
				void			*extraPV)
{
	PF_Err		err = PF_Err_NONE;
	
	try {
		switch (cmd) 
		{
			case PF_Cmd_ABOUT:
				
				err =	About(	in_data,
								out_data,
								params,
								output);
				break;
				
			case PF_Cmd_GLOBAL_SETUP:
				
				err =	GlobalSetup(in_data,
									out_data,
									params,
									output);
				break;
				
			case PF_Cmd_PARAMS_SETUP:
				
				err =	ParamsSetup(in_data,
									out_data,
									params,
									output);
				break;
				
			case PF_Cmd_RENDER:
				
				err =	Render(	in_data,
								out_data,
								params,
								output);
				break;
				
			case PF_Cmd_EVENT:
				
				err =	HandleEvent(in_data,
									out_data,
									params,
									output,
									reinterpret_cast<PF_EventExtra*>(extraPV));
				break;
		}
	}
	catch(PF_Err &thrown_err){
		err = PF_Err_BAD_CALLBACK_PARAM;
	}
	return err;
}

