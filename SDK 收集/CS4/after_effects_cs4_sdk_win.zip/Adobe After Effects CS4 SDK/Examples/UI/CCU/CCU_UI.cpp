/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2007 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

#include "CCU.h"

static 	PF_FixedPoint			std_oval[OVAL_PTS];

static void
InitOval (
		  PF_InData		*in_data,
		  PF_FixedPoint	*ovalP)
{
	AEGP_SuiteHandler		suites(in_data->pica_basicP);
	PF_FpLong 	radF		=	0;
	for (A_short iS = 0; iS < OVAL_PTS; ++iS) {
		radF		= (2.0 * iS * PF_PI) / OVAL_PTS;
		ovalP[iS].x = FLOAT_2_FIX(suites.ANSICallbacksSuite1()->sin(radF));
		ovalP[iS].y = FLOAT_2_FIX(suites.ANSICallbacksSuite1()->cos(radF));
	}
}

static void
TransformOval(	
	PF_InData			*in_data,
	PF_EventExtra		*extra, 
	PF_FixedRect		*fx_frame,
	PF_Point			*transformedPtP)
{
	AEGP_SuiteHandler	suites(in_data->pica_basicP);
	
	PF_FixedPoint		centerFiPt	=	{0,0};

	PF_FloatMatrix		mat;

	PF_FpLong			angleF 		= 	0, 
						dxF			=	0, 
						dyF			= 	0, 
						x_radF 		= 	0, 
						y_radF 		= 	0;

	PF_FixedPoint		copy_pts[OVAL_PTS];
	
	centerFiPt.x = (fx_frame->left 	+ fx_frame->right) 	/ 2;;
	centerFiPt.y = (fx_frame->top 	+ fx_frame->bottom) / 2;

	dxF = FIX_2_FLOAT(fx_frame->right - fx_frame->left);
	dyF = 0;	
	
	angleF	=	suites.ANSICallbacksSuite1()->atan2(dyF, dxF);
	angleF 	/=	PF_RAD_PER_DEGREE;
	
	x_radF = suites.ANSICallbacksSuite1()->sqrt(dxF * dxF + dyF * dyF) / 2.0;

	dxF	= 0;
	dyF	= FIX_2_FLOAT(fx_frame->bottom - fx_frame->top);
	
	y_radF	=	suites.ANSICallbacksSuite1()->sqrt(dxF * dxF + dyF * dyF) / 2.0;

	CCU_SetIdentityMatrix(&mat);

	CCU_ScaleMatrix(&mat, 
					x_radF, 
					y_radF, 
					0, 
					0);

	CCU_RotateMatrixPlus(	&mat, 
							in_data, 
							angleF, 
							0, 
							0);

	for (A_short iS = 0; iS < OVAL_PTS; iS++) {
		copy_pts[iS].x = std_oval[iS].x;
		copy_pts[iS].y = std_oval[iS].y;
	}
	
	CCU_TransformFixPoints(	&mat, 
							OVAL_PTS, 
							copy_pts);
	
	for (A_short jS = 0; jS < OVAL_PTS; jS++) {
		copy_pts[jS].x += centerFiPt.x;
		copy_pts[jS].y += centerFiPt.y;
	}

	for (A_short kS = 0; kS < OVAL_PTS; kS++) {
		extra->cbs.layer_to_comp(	extra->cbs.refcon, 
									extra->contextH, 
									in_data->current_time, 
									in_data->time_scale, 
									(PF_FixedPoint *)&(copy_pts[kS]));

		extra->cbs.source_to_frame( extra->cbs.refcon, 
									extra->contextH, 
									(PF_FixedPoint*)&(copy_pts[kS]));
	}
	
	for (A_short qS = 0; qS < OVAL_PTS; qS++) {
		transformedPtP[qS].h = FIX2INT_ROUND(copy_pts[qS].x);
		transformedPtP[qS].v = FIX2INT_ROUND(copy_pts[qS].y);
	}	
}

void	
PF_FrameOval(
	PF_InData		*in_data,
	PF_ContextH		contextH,
	PF_Rect			*rectRP)
{
#ifdef AE_OS_WIN
	HDC		hdc;
	PF_GET_CGRAF_DATA((*contextH)->cgrafptr, PF_CGrafData_HDC, (void**)&hdc);
	Arc(hdc, 
		(int)rectRP->left, 
		(int)rectRP->top, 
		(int)rectRP->right, 
		(int)rectRP->bottom,
		(int)rectRP->left, 
		(int)rectRP->top, 
		(int)rectRP->left, 
		(int)rectRP->top);
#else
	FrameOval(rectRP);
#endif
}

void
MyDrawOval(	
	PF_InData		*in_data,
	PF_EventExtra	*extra, 
	PF_FixedRect	*fx_frameP)
{
	PF_Point		poly_ovalPtA[OVAL_PTS];

	TransformOval(	in_data, 
					extra,
					fx_frameP, 
					poly_ovalPtA);

	PF_MoveTo(	in_data, 
				extra->contextH, 
				poly_ovalPtA[0].h, 
				poly_ovalPtA[0].v);

	for (A_short iS = 0; iS < OVAL_PTS; ++iS) {
		PF_LineTo(	in_data, 
					extra->contextH, 
					poly_ovalPtA[iS].h, 
					poly_ovalPtA[iS].v);
	}

	PF_LineTo(	in_data, 
				extra->contextH, 
				poly_ovalPtA[0].h, 
				poly_ovalPtA[0].v);
}

void 
FixedFrameFromParams (
	PF_InData		*in_data,
	PF_ParamDef		*params[],
	PF_FixedRect	*frameFiRP)
{
	A_long		xL		= params[CCU_PT]->u.td.x_value,		
				yL		= params[CCU_PT]->u.td.y_value,
				x_radL	= params[CCU_X_RADIUS]->u.fd.value,
				y_radL	= params[CCU_Y_RADIUS]->u.fd.value; 
	
	frameFiRP->top		= yL - y_radL;
	frameFiRP->bottom	= yL + y_radL;
	frameFiRP->left		= xL - x_radL;
	frameFiRP->right	= xL + x_radL;
}

void 
FrameFromParams (
	PF_InData		*in_data,
	PF_ParamDef		*params[],
	Rect			*frameRP)
{
	A_long		xL		= FIX2INT(params[CCU_PT]->u.td.x_value),		
				yL		= FIX2INT(params[CCU_PT]->u.td.y_value),
				x_radL	= FIX2INT(params[CCU_X_RADIUS]->u.fd.value),
				y_radL	= FIX2INT(params[CCU_Y_RADIUS]->u.fd.value); 
	
	frameRP->top		= (A_short)(yL - y_radL);
	frameRP->bottom		= (A_short)(yL + y_radL);
	frameRP->left		= (A_short)(xL - x_radL);
	frameRP->right		= (A_short)(xL + x_radL);
}
void 
Source2FrameRect (
				  PF_InData		*in_data,
				  PF_EventExtra	*event_extraP,
				  PF_FixedRect	*fx_frameRP,
				  PF_FixedPoint	*bounding_boxFiPtAP)		// array of four -> shows real bounding box

{
	bounding_boxFiPtAP[0].x = (fx_frameRP->left);
	bounding_boxFiPtAP[0].y = (fx_frameRP->top);
	
	bounding_boxFiPtAP[1].x = (fx_frameRP->right);
	bounding_boxFiPtAP[1].y = (fx_frameRP->top);
	
	bounding_boxFiPtAP[2].x = (fx_frameRP->right);
	bounding_boxFiPtAP[2].y = (fx_frameRP->bottom);
	
	bounding_boxFiPtAP[3].x = (fx_frameRP->left);
	bounding_boxFiPtAP[3].y = (fx_frameRP->bottom);
	
	if (PF_Window_COMP == (*event_extraP->contextH)->w_type) {
		for (A_short iS = 0; iS < 4; ++iS){
			event_extraP->cbs.layer_to_comp(	event_extraP->cbs.refcon, 
												event_extraP->contextH, 
												in_data->current_time, 
												in_data->time_scale, 
												&bounding_boxFiPtAP[iS]);
		}
	}
	for (A_short jS = 0; jS < 4; ++jS) {
		event_extraP->cbs.source_to_frame(	event_extraP->cbs.refcon, 
											event_extraP->contextH, 
											&bounding_boxFiPtAP[jS]);
	}	
	
	PF_SetFixedRect(fx_frameRP,
					bounding_boxFiPtAP[0].x,
					bounding_boxFiPtAP[0].y,
					bounding_boxFiPtAP[1].x,
					bounding_boxFiPtAP[2].y);
}

void	
CompFrame2Layer(
				PF_InData		*in_data,	
				PF_EventExtra	*event_extraP,		
				Point			*framePt,		
				Point			*lyrPt,		
				PF_FixedPoint	*fix_lyrFiPt)	
{
	fix_lyrFiPt->x = INT2FIX(framePt->h);
	fix_lyrFiPt->y = INT2FIX(framePt->v);
	
	event_extraP->cbs.frame_to_source(	event_extraP->cbs.refcon, 
										event_extraP->contextH, 
										fix_lyrFiPt);
	
	// now back into layer space
	
	event_extraP->cbs.comp_to_layer(event_extraP->cbs.refcon, 
									event_extraP->contextH, 
									in_data->current_time, 
									in_data->time_scale, 
									fix_lyrFiPt);
	
	lyrPt->h = fix_lyrFiPt->x;
	lyrPt->v = fix_lyrFiPt->y;
}

void 
Layer2CompFrame (
				 PF_InData		*in_data,	
				 PF_EventExtra	*event_extraP,		
				 Point			*layerPtP,		
				 Point			*framePtP,		
				 PF_FixedPoint	*fix_frameFiPtP)
{
	fix_frameFiPtP->x = INT2FIX(layerPtP->h);
	fix_frameFiPtP->y = INT2FIX(layerPtP->v);
	
	event_extraP->cbs.layer_to_comp(event_extraP->cbs.refcon, 
									event_extraP->contextH, 
									in_data->current_time, 
									in_data->time_scale, 
									fix_frameFiPtP);
	
	event_extraP->cbs.source_to_frame(	event_extraP->cbs.refcon, 
										event_extraP->contextH, 
										fix_frameFiPtP);
	
	framePtP->h = FIX2INT(fix_frameFiPtP->x);
	framePtP->v = FIX2INT(fix_frameFiPtP->y);
}

void	
LayerFrame2Layer(
				 PF_InData		*in_data,	
				 PF_EventExtra	*event_extraP,		
				 Point			*framePtP,	
				 Point			*lyrPtP,	
				 PF_FixedPoint	*fix_lyrPtP)
{
	fix_lyrPtP->x = INT2FIX(framePtP->h);
	fix_lyrPtP->y = INT2FIX(framePtP->v);
	
	event_extraP->cbs.frame_to_source(	event_extraP->cbs.refcon, 
										event_extraP->contextH, 
										fix_lyrPtP);
	
	// now back into layer space
	
	lyrPtP->h = FIX2INT(fix_lyrPtP->x);
	lyrPtP->v = FIX2INT(fix_lyrPtP->y);
}

void 
Layer2LayerFrame (
				  PF_InData		*in_data,	
				  PF_EventExtra	*event_extraP,		
				  Point			*layerPtP,		
				  Point			*framePtP,		
				  PF_FixedPoint	*fix_frameFiPtP)
{
	fix_frameFiPtP->x = INT2FIX(layerPtP->h);
	fix_frameFiPtP->y = INT2FIX(layerPtP->v);
	
	event_extraP->cbs.source_to_frame(	event_extraP->cbs.refcon, 
										event_extraP->contextH, 
										fix_frameFiPtP);
	
	framePtP->h = FIX2INT(fix_frameFiPtP->x);
	framePtP->v = FIX2INT(fix_frameFiPtP->y);
}

void 
DrawHandles (
	PF_InData		*in_data,
	PF_ParamDef		*params[],
	PF_EventExtra	*event_extraP)
{
	PF_Rect			boxR		=	{0,0,0,0};
					
	PF_FixedRect	fx_frameFiR	=	{0,0,0,0};

	PF_FixedPoint	pointsFiPtA[4];

	FixedFrameFromParams(in_data, params, &fx_frameFiR);

	if (PF_Window_COMP == (*event_extraP->contextH)->w_type) {
		MyDrawOval(	in_data, event_extraP,  &fx_frameFiR);
	}
	
	Source2FrameRect(in_data, event_extraP, &fx_frameFiR, pointsFiPtA);

	if (PF_Window_COMP == (*event_extraP->contextH)->w_type) {
		for (A_short iS = 0; iS < 4; iS++) {
			pointsFiPtA[iS].x 	= FIX2INT_ROUND(pointsFiPtA[iS].x);
			pointsFiPtA[iS].y 	= FIX2INT_ROUND(pointsFiPtA[iS].y);
			boxR.top			= pointsFiPtA[iS].y - 3;
			boxR.bottom			= pointsFiPtA[iS].y + 3;
			boxR.left			= pointsFiPtA[iS].x - 3;
			boxR.right			= pointsFiPtA[iS].x + 3;
			
			PF_InvertRect(	in_data, event_extraP->contextH, &boxR);
		}
	} else {
		
		PF_Rect			frameR;
		
		PF_FIXEDRECT_2_RECT(fx_frameFiR, frameR);
		
		PF_FrameOval(	in_data, 
						event_extraP->contextH, 
						&frameR);
	
		boxR.top		= frameR.top 	- 3;
		boxR.bottom		= frameR.top 	+ 3;
		boxR.left		= frameR.left 	- 3;
		boxR.right		= frameR.left 	+ 3;

		PF_InvertRect(	in_data, event_extraP->contextH, &boxR);
	
		boxR.top		= frameR.top 	- 3;
		boxR.bottom		= frameR.top 	+ 3;
		boxR.left		= frameR.right 	- 3;
		boxR.right		= frameR.right 	+ 3;

		PF_InvertRect(	in_data, event_extraP->contextH, &boxR);
	
		boxR.top		= frameR.bottom - 3;
		boxR.bottom		= frameR.bottom + 3;
		boxR.left		= frameR.left 	- 3;
		boxR.right		= frameR.left 	+ 3;

		PF_InvertRect(	in_data, event_extraP->contextH, &boxR);
	
		boxR.top		= frameR.bottom - 3;
		boxR.bottom		= frameR.bottom + 3;
		boxR.left		= frameR.right 	- 3;
		boxR.right		= frameR.right 	+ 3;

		PF_InvertRect(	in_data, event_extraP->contextH, &boxR);
	}	
}

PF_Err 
DrawEvent (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extraP)
{
	PF_Err			err 		= PF_Err_NONE;
	A_long			old_penL	= 0;

	if ((PF_Window_LAYER	==	(*event_extraP->contextH)->w_type)	||
		(PF_Window_COMP		==	(*event_extraP->contextH)->w_type)	) {

		old_penL = PF_PenXor(in_data, event_extraP->contextH);

		DrawHandles(in_data, params, event_extraP);

		PF_PenRestore(	in_data, 
						event_extraP->contextH, 
						old_penL);

		event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;
	}
	return err;
}

PF_Boolean 
DoClickHandles (
	PF_InData		*in_data,
	Rect			*frameRP,					
	PF_ParamDef		*params[],
	FrameFunc		frame_func,
	PF_EventExtra	*event_extraP)
{
	AEGP_SuiteHandler	suites(in_data->pica_basicP);
	
	PF_Boolean		doneB 			= 	FALSE;

	Point			mouse_downPt	=	{0,0}, 
					cornersPtA[4];

	PF_FixedPoint	mouse_layerFiPt	=	{0,0};

	A_short			hitS 		= 	-1;
					
	A_long			slopL 		= 	0;

	cornersPtA[0].h 	= frameRP->left;
	cornersPtA[0].v 	= frameRP->top;
	
	cornersPtA[1].h 	= frameRP->right;
	cornersPtA[1].v 	= frameRP->top;
	
	cornersPtA[2].h 	= frameRP->right;
	cornersPtA[2].v 	= frameRP->bottom;
	
	cornersPtA[3].h 	= frameRP->left;
	cornersPtA[3].v 	= frameRP->bottom;
  	
	mouse_downPt 		= *(reinterpret_cast<Point*>(&event_extraP->u.do_click.screen_point));

	for (A_short iS = 0; iS < 4; ++iS) {
		// convert cornersPtA to comp frameRP
		
		(*frame_func)(	in_data, 
						event_extraP, 
						&cornersPtA[iS], 
						&cornersPtA[iS], 
						&mouse_layerFiPt);
		
		slopL	= 		(long)suites.ANSICallbacksSuite1()->fabs(cornersPtA[iS].h	- mouse_downPt.h);
		slopL	+=	 	(long)suites.ANSICallbacksSuite1()->fabs(cornersPtA[iS].v	- mouse_downPt.v);
		
		if (slopL < CCU_SLOP) {
			hitS	= iS;
			doneB	= TRUE;

			event_extraP->u.do_click.send_drag				= TRUE;
			event_extraP->u.do_click.continue_refcon[0] 	= CCU_Handles;
			event_extraP->u.do_click.continue_refcon[1] 	= mouse_layerFiPt.x;
			event_extraP->u.do_click.continue_refcon[2] 	= mouse_layerFiPt.y;
			event_extraP->u.do_click.continue_refcon[3] 	= FALSE;				
			break;
		}
	}	
	return doneB;
}

PF_Boolean	
DoDragHandles(
	PF_InData		*in_data,
	PF_ParamDef		*params[],
	FrameFunc		frame_func,
	PF_EventExtra	*event_extraP)
{
	AEGP_SuiteHandler	suites(in_data->pica_basicP);
	
	PF_Boolean		doneB 			= FALSE;

	Point			mouse_downPt	=	{0,0};

	PF_FixedPoint	mouse_layerFiPt	=	{0,0},
					centerFiPt		=	{0,0},
					old_centerFiPt	=	{0,0};

	PF_Fixed		old_xL 			= 	0, 
					old_yL 			= 	0;

	PF_Boolean		drawB 			= 	TRUE;

	if (event_extraP->evt_in_flags & PF_EI_DONT_DRAW) {
		drawB = FALSE;
	}

	mouse_downPt = *(reinterpret_cast<Point*>(&event_extraP->u.do_click.screen_point));

	(*frame_func)(	in_data, 
					event_extraP, 
					&mouse_downPt, 
					(Point*)&mouse_downPt, 
					&mouse_layerFiPt);
 
 	old_centerFiPt.x = event_extraP->u.do_click.continue_refcon[1];
	old_centerFiPt.y = event_extraP->u.do_click.continue_refcon[2];
	
	centerFiPt.x = params[CCU_PT]->u.td.x_value;
	centerFiPt.y = params[CCU_PT]->u.td.y_value;
	
	if (FALSE == event_extraP->u.do_click.continue_refcon[3]) {
		if (drawB) {
			// draw new
			DrawHandles(in_data, params, event_extraP);		
		}
	}
	old_xL = params[CCU_X_RADIUS]->u.fd.value;
	old_yL = params[CCU_Y_RADIUS]->u.fd.value;
	
	params[CCU_X_RADIUS]->u.fd.value 		= (A_long)suites.ANSICallbacksSuite1()->fabs(centerFiPt.x - mouse_layerFiPt.x);
	params[CCU_Y_RADIUS]->u.fd.value 		= (A_long)suites.ANSICallbacksSuite1()->fabs(centerFiPt.y - mouse_layerFiPt.y);

	params[CCU_X_RADIUS]->uu.change_flags 	= PF_ChangeFlag_CHANGED_VALUE;
	params[CCU_Y_RADIUS]->uu.change_flags 	= PF_ChangeFlag_CHANGED_VALUE;

	if (drawB) 	{

		// draw new

		DrawHandles(in_data, params, event_extraP);		
		params[CCU_X_RADIUS]->u.fd.value = old_xL;
		params[CCU_Y_RADIUS]->u.fd.value = old_yL;
		
		// erase old
		
		DrawHandles(in_data, params, event_extraP);		
		params[CCU_X_RADIUS]->u.fd.value = ABS(centerFiPt.x - mouse_layerFiPt.x);
		params[CCU_Y_RADIUS]->u.fd.value = ABS(centerFiPt.y - mouse_layerFiPt.y);
	}
		
	doneB 											= TRUE;
	event_extraP->u.do_click.send_drag 				= TRUE;
	event_extraP->u.do_click.continue_refcon[0] 	= CCU_Handles;
	event_extraP->u.do_click.continue_refcon[1] 	= mouse_layerFiPt.x;
	event_extraP->u.do_click.continue_refcon[2] 	= mouse_layerFiPt.y;
	event_extraP->u.do_click.continue_refcon[3] 	= TRUE;
	
	if (event_extraP->u.do_click.last_time) {
		event_extraP->u.do_click.continue_refcon[0] = 0;
		event_extraP->u.do_click.send_drag 			= FALSE;

		if (drawB){
			// draw new
			DrawHandles(in_data, params, event_extraP);		
		}
	}	
	return doneB;
	
}

PF_Boolean 
DoClickRect (
	PF_InData		*in_data,
	Rect			*frameRP,
	PF_ParamDef		*params[],
	FrameFunc		frame_func,
	PF_EventExtra	*event_extraP)
{
	PF_Boolean		doneB 			=	FALSE;

	Point			mouse_downPt	=	{0,0};

	PF_FixedPoint	mouse_layerFiPt =	{0,0};

	mouse_downPt = *(reinterpret_cast<Point*>(&event_extraP->u.do_click.screen_point));

	(*frame_func)(	in_data, 
					event_extraP, 
					&mouse_downPt, 
					&mouse_downPt, 
					&mouse_layerFiPt);
	
	if (MacPtInRect(mouse_downPt, frameRP)) {
		doneB		 									= TRUE;
		event_extraP->u.do_click.send_drag 				= TRUE;
		event_extraP->u.do_click.continue_refcon[0] 	= CCU_Rect;
		event_extraP->u.do_click.continue_refcon[1] 	= mouse_layerFiPt.x;
		event_extraP->u.do_click.continue_refcon[2] 	= mouse_layerFiPt.y;
		event_extraP->u.do_click.continue_refcon[3] 	= FALSE;
	}
	return doneB;	
}

PF_Boolean 
DoDragRect (
	PF_InData		*in_data,
	PF_ParamDef		*params[],
	FrameFunc		frame_func,
	PF_EventExtra	*event_extraP)
{
	PF_Boolean		doneB 			=	FALSE, 
					drawB 			=	TRUE;

	Point			mouse_downPt	=	{0,0};

	PF_FixedPoint	mouse_layerFiPt	=	{0,0}, 
					dFiPt			=	{0,0};
	
	if (event_extraP->evt_in_flags & PF_EI_DONT_DRAW) {
		drawB = FALSE;
	}

	mouse_downPt = *(reinterpret_cast<Point*>(&event_extraP->u.do_click.screen_point));

	(*frame_func)(	in_data, 
					event_extraP, 
					&mouse_downPt, 
					&mouse_downPt, 
					&mouse_layerFiPt);

	dFiPt.x = mouse_layerFiPt.x - event_extraP->u.do_click.continue_refcon[1];
	dFiPt.y = mouse_layerFiPt.y - event_extraP->u.do_click.continue_refcon[2];

	if (FALSE == event_extraP->u.do_click.continue_refcon[3]) {
		if (drawB) {
			DrawHandles(in_data, params, event_extraP);		
		}
	}
	
	params[CCU_PT]->u.td.x_value 	+= (dFiPt.x);
	params[CCU_PT]->u.td.y_value 	+= (dFiPt.y);

	params[CCU_PT]->flags			|= PF_ChangeFlag_CHANGED_VALUE;

	if (drawB) {
		//draw new
		
		DrawHandles(in_data, params, event_extraP);		
		params[CCU_PT]->u.td.x_value -= (dFiPt.x);
		params[CCU_PT]->u.td.y_value -= (dFiPt.y);

		//erase old
		
		DrawHandles(in_data, params, event_extraP);	
		params[CCU_PT]->u.td.x_value += (dFiPt.x);
		params[CCU_PT]->u.td.y_value += (dFiPt.y);
	}

	doneB 											= TRUE;
	event_extraP->u.do_click.send_drag				= TRUE;
	event_extraP->u.do_click.continue_refcon[0] 	= CCU_Rect;
	event_extraP->u.do_click.continue_refcon[1] 	= mouse_layerFiPt.x;
	event_extraP->u.do_click.continue_refcon[2] 	= mouse_layerFiPt.y;
	event_extraP->u.do_click.continue_refcon[3] 	= TRUE;
	
	if (event_extraP->u.do_click.last_time) {
		event_extraP->u.do_click.continue_refcon[0] 	= 0;
		event_extraP->u.do_click.send_drag 			= FALSE;

		if (drawB) {
			// draw new
			DrawHandles(in_data, params, event_extraP);		
		}
	}
	return doneB;
}

PF_Err 
DoClick (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extraP)
{
	PF_Err 					err 		= 	PF_Err_NONE;
	PF_ContextH				contextH 	= 	event_extraP->contextH;
	Rect					frameR		=	{0,0,0,0};
	
	PenState				old_pen_state;

	GetPenState(&old_pen_state);
	
	FrameFromParams(in_data, 
					params, 
					&frameR);
	
	PenMode(patXor);

	if (PF_Window_LAYER == (*contextH)->w_type) {
		if (DoClickHandles(	in_data, 
							&frameR, 
							params, 
							Layer2LayerFrame, 
							event_extraP)) 	{
			event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;
		} else if (DoClickRect(	in_data, 
								&frameR, 
								params, 
								LayerFrame2Layer, 
								event_extraP)) {
			event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;
		}
		
	} else if (PF_Window_COMP == (*contextH)->w_type) {
		if (DoClickHandles(	in_data, 
							&frameR, 
							params, 
							Layer2CompFrame, 
							event_extraP)) {
			event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;
		} else if (DoClickRect(	in_data, 
								&frameR, 
								params, 
								CompFrame2Layer, 
								event_extraP)) {
			event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;
		}
	}

	SetPenState(&old_pen_state);	

	return err;
}

PF_Err	
DoDrag(
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output,
	PF_EventExtra	*event_extraP)
{
	PF_Err 					err 		= 	PF_Err_NONE;
	PF_ContextH				contextH 	= 	event_extraP->contextH;

	PF_DoClickEventInfo 	do_click;

	FrameFunc				frame_func	= 	NULL;

	PenState				old_pen_state;
	Rect					framePR		=	{0,0,0,0};

	AEFX_CLR_STRUCT(do_click);
	
	GetPenState(&old_pen_state);

	FrameFromParams(in_data, 
					params, 
					&framePR);

	PenMode(patXor);

	do_click = event_extraP->u.do_click;
	
	if (PF_Window_LAYER == (*contextH)->w_type) {
		frame_func = LayerFrame2Layer;
	} else if (PF_Window_COMP == (*contextH)->w_type) {
		frame_func = CompFrame2Layer;
	}
	
	if (frame_func) {
		switch (do_click.continue_refcon[0]) {
			
			case CCU_Rect:

				DoDragRect(	in_data, 
							params, 
							frame_func, 
							event_extraP);

				event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;

				break;
			
			case CCU_Handles:

				DoDragHandles(	in_data, 
								params, 
								frame_func, 
								event_extraP);

				event_extraP->evt_out_flags = PF_EO_HANDLED_EVENT;

				break;
		}
	}
	SetPenState(&old_pen_state);
	return err;
}

PF_Err 
HandleEvent (
			 PF_InData		*in_data,
			 PF_OutData		*out_data,
			 PF_ParamDef		*params[],
			 PF_LayerDef		*output,
			 PF_EventExtra	*event_extraP)
{
	PF_Err		err = PF_Err_NONE;
	
	if (PF_Event_DO_CLICK == event_extraP->e_type) {
		if (event_extraP->u.do_click.send_drag) {
			event_extraP->e_type = PF_Event_DRAG;
		}
	}
	
	switch (event_extraP->e_type) {
		
		case PF_Event_NEW_CONTEXT:
			InitOval(in_data, std_oval);
			break;
			
		case PF_Event_ACTIVATE:
			break;
			
		case PF_Event_DO_CLICK:
			DoClick(in_data, 
					out_data, 
					params, 
					output, 
					event_extraP);
			break;
			
		case PF_Event_DRAG:
			DoDrag(	in_data, 
					out_data, 
					params, 
					output, 
					event_extraP);
			break;
			
		case PF_Event_DRAW:
			DrawEvent(	in_data, 
						out_data, 
						params, 
						output, 
						event_extraP);
			break;
			
		case PF_Event_DEACTIVATE:
			break;
			
		case PF_Event_CLOSE_CONTEXT:
			break;
			
		default:
		case PF_Event_IDLE:
			break;
			
	}
	return err;
}
