#pragma once

typedef enum {
	StrID_NONE, 
	StrID_LayerName,
	StrID_ModePopName,
	StrID_ModePopChoices, 

	StrID_FlavorName,
	StrID_FlavorChoices,	
	StrID_ColorHard,
	StrID_ColorEasy,
	StrID_FlavorHard, 

	StrID_SliderHard, 
	StrID_SliderEasy, 

	StrID_Check1Hard, 
	StrID_Check1Easy,
	StrID_Check1Changed,

	StrID_Check2Hard, 
	StrID_Check2Easy, 

	StrID_Err_LoadSuite,
	StrID_Err_FreeSuite, 

	StrID_TopicName,
	StrID_TopicNameDisabled, 
	StrID_FlavorDisabled,
	StrID_Name,	
	StrID_Description,
	StrID_ColorError,
	StrID_GeneralError,

	
	StrID_NUMTYPES
} StrIDType;

#ifdef __cplusplus
extern "C" {
#endif
char	*GetStringPtr(int strNum);
#ifdef __cplusplus
}
#endif