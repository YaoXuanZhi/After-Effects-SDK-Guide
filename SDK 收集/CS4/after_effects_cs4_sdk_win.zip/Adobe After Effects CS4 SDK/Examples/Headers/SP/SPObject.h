/******************************************************************************
					SPObject.h
									
Purpose:
	Defines the suite for registering and creating Sweet Pea objects.
	It is a "conventional" Sweet Pea suite used to provide
	COM-like objects from Sweet Pea plugins.
									
	Copyright (c) 1995-1998, 2002 Adobe Systems Incorporated.
******************************************************************************/
/* $Id: $  */
/* $DateTime: $  */
/* $Change: $  */
/* $Author: $  */
#pragma once
#ifndef __SPObject__
#define __SPObject__
/* This module is obsolete. */
#endif	/* __SPObject__ */
