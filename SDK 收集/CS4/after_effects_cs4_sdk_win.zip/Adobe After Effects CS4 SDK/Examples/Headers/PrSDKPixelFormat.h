/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2002 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/

#ifndef PRSDKPIXELFORMAT_H
#define PRSDKPIXELFORMAT_H

#ifndef PRSDKTYPES_H
//#include "PrSDKTypes.h"
#endif

#ifndef MAKE_PIXEL_FORMAT_FOURCC
#define MAKE_PIXEL_FORMAT_FOURCC(ch0, ch1, ch2, ch3)                              \
                ((unsigned long)(unsigned char)(ch0) | ((unsigned long)(unsigned char)(ch1) << 8) |       \
                ((unsigned long)(unsigned char)(ch2) << 16) | ((unsigned long)(unsigned char)(ch3) << 24 ))
#endif

/**
**	Premiere supported pixel formats for RenderFrame and PPixs
*/

enum PrPixelFormat
{

/**
**	Currently supported types
*/

// Packed formats
PrPixelFormat_BGRA_4444_8u		= MAKE_PIXEL_FORMAT_FOURCC('b', 'g', 'r', 'a'),		// 4 byte BGRA, standard windows 32 bit pixels (was kPixelFormat_BGRA32)
PrPixelFormat_VUYA_4444_8u		= MAKE_PIXEL_FORMAT_FOURCC('v', 'u', 'y', 'a'),		// 4 byte VUYA (was kPixelFormat_VUYA32)
PrPixelFormat_ARGB_4444_8u		= MAKE_PIXEL_FORMAT_FOURCC('a', 'r', 'g', 'b'),		// 4 byte ARGB (the format used by AE) (was kPixelFormat_ARGB32)
																										   
PrPixelFormat_BGRA_4444_16u		= MAKE_PIXEL_FORMAT_FOURCC('B', 'g', 'r', 'a'),		// 16 bit integer per component BGRA
PrPixelFormat_VUYA_4444_16u		= MAKE_PIXEL_FORMAT_FOURCC('V', 'u', 'y', 'a'),		// 16 bit integer per component VUYA
PrPixelFormat_ARGB_4444_16u		= MAKE_PIXEL_FORMAT_FOURCC('A', 'r', 'g', 'b'),		// 16 bit integer per component ARGB 

PrPixelFormat_BGRA_4444_32f		= MAKE_PIXEL_FORMAT_FOURCC('B', 'G', 'r', 'a'),		// 32 bit float per component BGRA
PrPixelFormat_VUYA_4444_32f		= MAKE_PIXEL_FORMAT_FOURCC('V', 'U', 'y', 'a'),		// 32 bit float per component VUYA
PrPixelFormat_ARGB_4444_32f		= MAKE_PIXEL_FORMAT_FOURCC('A', 'R', 'g', 'b'),		// 32 bit float per component ARGB 


PrPixelFormat_YUYV_422_8u_601	= MAKE_PIXEL_FORMAT_FOURCC('y', 'u', 'y', '2'),		// 8 bit 422 YUY2 601 colorspace
PrPixelFormat_YUYV_422_8u_709	= MAKE_PIXEL_FORMAT_FOURCC('y', 'u', 'y', '3'),		// 8 bit 422 YUY2 709 colorspace

PrPixelFormat_UYVY_422_8u_601	= MAKE_PIXEL_FORMAT_FOURCC('u', 'y', 'v', 'y'),		// 8 bit 422 UYVY 601 colorspace
PrPixelFormat_UYVY_422_8u_709	= MAKE_PIXEL_FORMAT_FOURCC('u', 'y', 'v', '7'),		// 8 bit 422 UYVY 709 colorspace

PrPixelFormat_V210_422_10u_601	= MAKE_PIXEL_FORMAT_FOURCC('v', '2', '1', '0'),		// packed uncompressed 10 bit 422 YUV aka V210 601 colorspace
PrPixelFormat_V210_422_10u_709	= MAKE_PIXEL_FORMAT_FOURCC('v', '2', '1', '1'),		// packed uncompressed 10 bit 422 YUV aka V210 709 colorspace

// Planar formats
PrPixelFormat_YUV_420_MPEG2_FRAME_PICTURE_PLANAR_8u_601	= MAKE_PIXEL_FORMAT_FOURCC('y', 'v', '1', '2'),		//	YUV with 2x2 chroma subsampling. Planar. (for MPEG-2)
PrPixelFormat_YUV_420_MPEG2_FIELD_PICTURE_PLANAR_8u_601	= MAKE_PIXEL_FORMAT_FOURCC('y', 'v', 'i', '2'),		//	YUV with 2x2 chroma subsampling. Planar. (for MPEG-2)
PrPixelFormat_YUV_420_MPEG2_FRAME_PICTURE_PLANAR_8u_709	= MAKE_PIXEL_FORMAT_FOURCC('y', 'v', '1', '7'),		//	YUV with 2x2 chroma subsampling. Planar. (for MPEG-2) 709 colorspace
PrPixelFormat_YUV_420_MPEG2_FIELD_PICTURE_PLANAR_8u_709	= MAKE_PIXEL_FORMAT_FOURCC('y', 'v', 'i', '7'),		//	YUV with 2x2 chroma subsampling. Planar. (for MPEG-2) 709 colorspace

// Compressed formats
PrPixelFormat_NTSCDV25			= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'n', '2'),		//	compressed DV-25
PrPixelFormat_PALDV25			= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'p', '2'),		//	compressed DV-25
PrPixelFormat_NTSCDV50			= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'n', '5'),
PrPixelFormat_PALDV50			= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'p', '5'),
PrPixelFormat_NTSCDV100_720p	= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'n', '7'),		//	compressed DV-100 720p, 60 Hz
PrPixelFormat_PALDV100_720p		= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'p', '7'),		//	compressed DV-100 720p, 50 Hz
PrPixelFormat_NTSCDV100_1080i	= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'n', '1'),		//	compressed DV-100 1080i, 60 Hz
PrPixelFormat_PALDV100_1080i	= MAKE_PIXEL_FORMAT_FOURCC('d', 'v', 'p', '1'),		//	compressed DV-100 1080i, 50 Hz
PrPixelFormat_Nutr				= MAKE_PIXEL_FORMAT_FOURCC('n', 'u', 't', 'r'),		//	neutrino codec

// Raw, opaque data formats
PrPixelFormat_Raw			= MAKE_PIXEL_FORMAT_FOURCC('r', 'a', 'w', 'w'),		// raw, opaque data, with no row bytes or height.

// Invalid
PrPixelFormat_Invalid		= MAKE_PIXEL_FORMAT_FOURCC('b', 'a', 'd', 'f'),		// invalid pixel format - this is used for intialization and erorr conditions

PrPixelFormat_Any			= 0
};

#endif // PRSDKPIXELFORMAT_H

