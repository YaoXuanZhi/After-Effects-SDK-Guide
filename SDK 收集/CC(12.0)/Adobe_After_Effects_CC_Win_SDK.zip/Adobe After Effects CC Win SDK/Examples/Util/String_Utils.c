#include "String_Utils.h"

A_char	*GetStringPtr(int strNum)
{
	return g_strs[strNum].str;
}